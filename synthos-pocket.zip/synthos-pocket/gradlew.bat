@echo off
setlocal EnableExtensions EnableDelayedExpansion
set GRADLE_VERSION=8.9
set BASE_DIR=%~dp0
set GRADLE_SYSTEM_VERSION=
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  for /f "delims=" %%v in ('gradle --version ^| findstr /R /C:"^Gradle 8[.]9$"') do set GRADLE_SYSTEM_VERSION=%%v
  if "!GRADLE_SYSTEM_VERSION!"=="Gradle 8.9" (
    gradle -p "%BASE_DIR%" %*
    exit /b !ERRORLEVEL!
  )
)
set CACHE_ROOT=%USERPROFILE%\.gradle\synthos-bootstrap
set GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $v='%GRADLE_VERSION%'; $base='%CACHE_ROOT%'; $url='https://services.gradle.org/distributions/gradle-'+$v+'-bin.zip'; $zip=Join-Path $base ('gradle-'+$v+'-bin.zip'); Invoke-WebRequest -Uri $url -OutFile $zip; $sumText=(Invoke-WebRequest -Uri ($url+'.sha256')).Content; $expected=($sumText -split '\s+')[0].Trim(); $actual=(Get-FileHash -Algorithm SHA256 $zip).Hash.ToLowerInvariant(); if ($actual -ne $expected.ToLowerInvariant()) { Remove-Item $zip -Force; throw 'Gradle checksum verification failed.' }; Expand-Archive -Path $zip -DestinationPath $base -Force; Remove-Item $zip -Force"
  if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
)
call "%GRADLE_HOME%\bin\gradle.bat" -p "%BASE_DIR%" %*
exit /b %ERRORLEVEL%
