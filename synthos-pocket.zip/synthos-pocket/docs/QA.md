# Release QA checklist

## Automated checks — GitHub Actions

The existing root workflow runs `testDebugUnitTest`, `lintDebug` and `assembleDebug`, then uploads `synthos-pocket-debug-apk`. A run is the source of truth for Android compilation. These commands have not been reported as passing in the current editing runtime because the Android SDK is absent and dependencies cannot be downloaded here.

Unit tests currently cover prompt composition, independent/convergence role rules, selected-context bounds, backup compatibility, mission links/context IDs and local chat history/context assembly.

## Local model and mission checks (physical Android device required)

1. Install the debug APK over the previous debug build. Verify the encrypted workspace remains available.
2. Start a mission, choose a mode and select two sources. Leave the screen, reopen the mission and verify goal, mode and selected sources persist.
3. In Settings, import a known-compatible small `.litertlm` model. Reject unrelated extensions; cancel the picker; try an unreadable or malformed model file. A failed import must not delete a previously working model.
4. Ask a local question. Verify initialization happens off the main thread, genuine tokens stream, the question is persisted before inference, and a completed answer is persisted with the correct mission link.
5. Send a second turn. Verify the bounded previous user/assistant turns are restored in chronological order and no duplicate turns appear.
6. Switch tabs and return while generation is running. Verify the result is either visibly still in progress or saved and surfaced, never duplicated or presented as completed before the model finishes.
7. Lock the workspace during generation. Verify generation cancellation, engine/conversation teardown, and clearing of sensitive in-memory captures. Re-unlock; ensure the question is retained and no partial answer is mislabelled as complete.
8. Replace the model while idle. Confirm the old engine closes before replacement. Test a failed replacement and verify the prior model remains usable.
9. Remove the local model. Confirm mission history, local chat turns and captured sources remain. Restart the app and confirm the setup state is correct.
10. Benchmark first-load latency, sustained token speed, memory use, heat and battery for the chosen device/model. Try a model too large for available RAM and verify the failure is clear and recoverable.

## Handoffs and return loop

11. Share a URL from a browser to SynthOS. Inspect/edit the incoming capture, then save or make a mission. Restart and find the source in Library.
12. Open an existing mission, prepare a Researcher/Architect/Challenger brief, inspect it and share to an installed AI app. Confirm the brief contains only selected records and explicit source labels.
13. Run the external prompt manually. Share its answer back to SynthOS and save it linked to the originating mission. Confirm a later local conversation can refer to the linked result.
14. For Compete, get independent answers without exposing the other answer first. For Converge, check the prompt preserves unresolved objections instead of demanding consensus.
15. Try a long shared message and plain URL; handle absent MIME metadata and cancellation without crash.

## Storage and accessibility

16. Export a backup and inspect the warning that JSON is plaintext. Restore into a separate instance and verify parent links, mode and selected context survive. Legacy backup records with missing optional fields should still decode.
17. Delete a selected source and verify it is removed from mission context without clearing other records.
18. Check storage-full/read-write errors: never report success when persistence fails, and don't replace a readable workspace after a failed decrypt/read.
19. Verify biometric/device authentication, lock/unlock and process recreation on supported phones.
20. Check light/dark/system themes, narrow screen, large system font, TalkBack focus order and labels, 48 dp target convention, keyboard resize and scrolling with the IME open.

## Known verification gap

The deliverable is a source ZIP plus the existing build workflow, not a built or signed release APK. No emulator or physical device was available in this runtime. CI compilation and all native LiteRT-LM model inference, latency, thermal, accessibility and lifecycle checks must still be completed before relying on this build.
