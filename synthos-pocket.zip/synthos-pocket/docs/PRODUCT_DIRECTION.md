# SynthOS — Product direction

## Promise

**SynthOS keeps the thread of work intact as you move between your private context, on-device intelligence, external AI models, apps and the real world.**

The target user is a builder, researcher or operator who regularly carries one problem between AI chats, browser pages, files and real decisions. Their tax is not a lack of AI buttons; it is lost continuity, repeated context handoffs and outputs that are hard to verify or reuse.

SynthOS is a capture-first private work environment whose missions preserve continuity when a captured item becomes a longer task. The local model is the conversational coordinator—not an omniscient agent. The project is the source of continuity. Specialist models and apps are optional workers invoked through a clear boundary. The user stays in control of what context leaves the device.

## Core loop

Goal → durable context → local conversation → focused specialist handoffs → returned evidence/artifacts → comparison or revision → next action.

## MVP in this source snapshot

- A capture-first Work home with a reviewable Inbox, mission room and recent continuity; three destinations only: Work, Library and Settings.
- Persistent Collaborate / Compete / Converge strategies inside a mission.
- Durable, user-controlled context selection (up to eight linked records).
- A local chat surface powered by LiteRT-LM on Android, with one-tap downloads for several pre-converted Qwen models plus an import path for custom compatible weights.
- The local prompt compiler provides the goal, selected records and linked external work with hard bounds; it explicitly tells the model what it cannot access or verify.
- Streaming on-device answers, persisted with the same mission and reconstructed local chat history.
- Specialist prompts for complementary collaboration, independent competing proposals, and proposal / critique / reconciliation.
- Tracked external sessions: save each handoff to its mission, open Android's system destination chooser, record the chosen target, and accept returned material as context. Share-in from compatible apps can be saved as a resumable mission with the source transcript attached. `ACTION_SEND_MULTIPLE` can import up to five file URIs with a 2 MB-per-file / 6 MB-total bound; imported bytes are retained in the encrypted record only after review and explicit save.
- Optional floating capture bubble (requires Android's display-over-other-apps permission) to bring copied material into SynthOS for review from another app.
- Encrypted local workspace, search/edit/delete, plaintext-warning backup/export, backup restore and light/dark/system themes.

## Hard product boundaries

1. **No model bundled.** Settings offers direct one-tap downloads for three public LiteRT-LM Qwen3 variants and accepts custom `.litertlm` files. A model file accepted by the downloader or picker is not guaranteed to initialize on every phone; real device tests are required. Local inference uses the CPU backend initially, so speed, heat and RAM remain device/model dependent.
2. **No fake parallelism.** This release can prepare multiple handoffs and discuss returned results locally, but does not claim to invoke external providers concurrently. Android's system destination chooser gives the user explicit control; each external app is a separate interaction. Model downloads need internet access, but local inference does not use the network.
3. **No universal app control.** Android intents and sharing are the foundation. The optional floating capture overlay is limited to user-initiated clipboard capture and explicit review; it does not read screen contents or operate other apps. Native-app automation and broad Accessibility Service access remain deferred due to reliability, sensitive permissions and policy limits.
4. **No generic scraper engine yet.** Browser automation needs an inspectable session, site-specific recipe validation, failure recovery and careful login boundaries.
5. **No cloud sync or account system.** The local workspace is the source of truth for this iteration.

## Experience architecture

- **Work:** capture entry, review Inbox, mission composer, recent missions and recent sources. Shared content is reviewed before saving; no pre-category is required.
- **Mission room:** goal and mode; durable selected context; the local SynthOS conversation; specialist handoffs; linked returned work. This replaces disconnected Research/Debate destinations.
- **Library:** inspect, search, edit, delete and choose source material.
- **Settings:** privacy explanation, model import/remove, appearance and backup/restore.
- **Context compiler:** deterministic, bounded, provenance-aware prompt composition. It never silently ships the complete library.
- **Local runtime:** LiteRT-LM adapter behind a small Kotlin boundary; CPU backend first; model initialization, streaming and teardown on a dedicated background dispatcher; explicit cancel on lock or model replacement.
- **Capture model:** original source, local AI user/assistant turn and external response use explicit provenance labels and stable mission relationships. These states are not conflated with “verified fact.”

## Acceptance criteria

1. Start a mission; close the app; reopen and recover the same goal, mode and selected context.
2. Install a catalog model with one tap or import a compatible local model. Invalid extension, incomplete download, low storage or failed replacement must not overwrite a working model. Switch between installed models and remove any one without deleting the others.
3. Ask a local question. Show genuine loading/streaming states only while native work is underway, persist the question before generation and save the assistant response to the same mission after success.
4. Reopen a mission and reconstruct a bounded recent local chat history in order.
5. Lock during generation: cancel/stop generation, close native resources safely and clear sensitive in-memory workspace state. Do not commit a partial response as complete.
6. Removing weights preserves encrypted mission conversations. Replacing a model closes the old runtime first.
7. Select library sources, inspect a specialist brief and verify that only selected records plus explicit metadata are included.
8. Start a specialist handoff and confirm it is saved before the system chooser opens. Confirm the chosen destination is recorded; share the reply back and save it to the same mission. A subsequent local turn can compare it with other linked results.
9. Share an existing chat transcript into SynthOS, make a mission, restart the app and continue the mission. Verify that the original transcript stays inspectable and is prioritized in bounded local prompt context.
10. Backup/restore preserves mission mode, context links, provenance, parent links and bounded attachment bytes; schema v1 backups remain readable. Exported JSON remains plaintext and must be protected.
11. Light/dark/system themes, increased system font sizes, TalkBack, touch targets and small-screen scrolling remain usable.
12. `ACTION_SEND` and `ACTION_SEND_MULTIPLE` review/saves preserve text and supported content URIs. Test the attachment count/size boundaries, URI permission expiry, provider read errors, and encrypted backup round-trip.
13. The UI never claims an external provider is connected or working unless the user has actually invoked it. A model file being installed does not prove it can initialize.

## What follows after MVP

### 1. Verify the local foundation

Run CI and device checks. Benchmark two small supported models on the target phone for memory, first-token latency, steady-state tokens/sec, battery/heat, multilingual usefulness and source-grounding. Add a model compatibility/requirements display based on metadata where available; do not hide failures behind generic success UI.

### 2. Make parallel workers real

Add a provider-neutral worker interface and provider adapters where official APIs/credentials are available. Run independent proposal calls concurrently, preserve every transcript and execution status, allow cancellation per worker, and attach evidence and actual test results. Handoffs through native apps remain user-driven unless the integration supports reliable automation.

### 3. Bounded council

Independent draft → cross-critique → rebuttal/revision → judge against task-specific criteria. Use budgets and max rounds. Preserve unresolved disagreement. A test result or corroborated source should outweigh model confidence or a vote count.

### 4. Visible browser workbench

A controlled WebView/session that shows actions and sources, begins with public pages, validates data extraction and saves versioned recipes. Login, CAPTCHA, blocked interactions and destructive actions should halt for user input, not be bypassed.

### 5. Reusable missions and skills

Make proven workflows editable/versioned and re-run them with explicit success criteria. The local model can suggest a decomposition, relevant records or a recipe change, but the user reviews any material change before it runs.

## Non-negotiables

- Original sources and derived model output remain distinguishable.
- User-selected context is inspectable and bounded.
- There is no silent external disclosure or pretend activity.
- A result is not “verified” without an actual check.
- The runtime is replaceable; SynthOS owns the mission and context.
- Failures preserve the last working file and the encrypted workspace.
