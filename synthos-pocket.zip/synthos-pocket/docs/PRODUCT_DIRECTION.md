# SynthOS — Product direction

## Promise

**SynthOS keeps the thread of work intact as you move between your private context, on-device intelligence, external AI models, apps and the real world.**

The target user is a builder, researcher or operator who regularly carries one problem between AI chats, browser pages, files and real decisions. Their tax is not a lack of AI buttons; it is lost continuity, repeated context handoffs and outputs that are hard to verify or reuse.

SynthOS is a persistent mission workspace. The local model is the conversational coordinator—not an omniscient agent. The project is the source of continuity. Specialist models and apps are optional workers invoked through a clear boundary. The user stays in control of what context leaves the device.

## Core loop

Goal → durable context → local conversation → focused specialist handoffs → returned evidence/artifacts → comparison or revision → next action.

## MVP in this source snapshot

- A mission-first home and mission room; three destinations only: Work, Library and Settings.
- Persistent Collaborate / Compete / Converge strategies inside a mission.
- Durable, user-controlled context selection (up to eight linked records).
- A local chat surface powered by LiteRT-LM on Android when the user imports compatible model weights.
- The local prompt compiler provides the goal, selected records and linked external work with hard bounds; it explicitly tells the model what it cannot access or verify.
- Streaming on-device answers, persisted with the same mission and reconstructed local chat history.
- Specialist prompts for complementary collaboration, independent competing proposals, and proposal / critique / reconciliation.
- Android Sharesheet handoff to other AI apps and share-in from compatible apps.
- Encrypted local workspace, search/edit/delete, plaintext-warning backup/export, backup restore and light/dark/system themes.

## Hard product boundaries

1. **No model bundled.** Users import `.litertlm` weights from the supported ecosystem, e.g. a CPU-compatible model such as [LiteRT Community Qwen3-0.6B](https://huggingface.co/litert-community/Qwen3-0.6B). A model file accepted by the picker is not guaranteed to initialize on every phone; real device tests are required. Local inference uses the CPU backend initially, so speed, heat and RAM remain device/model dependent.
2. **No fake parallelism.** This release can prepare multiple handoffs and discuss returned results locally, but does not claim to invoke external providers concurrently. Android's Sharesheet gives the user explicit control; each external app is a separate interaction.
3. **No universal app control.** Android intents and sharing are the foundation. Native-app automation, global overlay and Accessibility Service access are deferred due to reliability, sensitive permissions and policy limits.
4. **No generic scraper engine yet.** Browser automation needs an inspectable session, site-specific recipe validation, failure recovery and careful login boundaries.
5. **No cloud sync or account system.** The local workspace is the source of truth for this iteration.

## Experience architecture

- **Work:** goal composer, recent missions and recent captures. A shared item is always reviewed before it is saved.
- **Mission room:** goal and mode; durable selected context; the local SynthOS conversation; specialist handoffs; linked returned work. This replaces disconnected Research/Debate destinations.
- **Library:** inspect, search, edit, delete and choose source material.
- **Settings:** privacy explanation, model import/remove, appearance and backup/restore.
- **Context compiler:** deterministic, bounded, provenance-aware prompt composition. It never silently ships the complete library.
- **Local runtime:** LiteRT-LM adapter behind a small Kotlin boundary; CPU backend first; model initialization, streaming and teardown on a dedicated background dispatcher; explicit cancel on lock or model replacement.
- **Capture model:** original source, local AI user/assistant turn and external response use explicit provenance labels and stable mission relationships. These states are not conflated with “verified fact.”

## Acceptance criteria

1. Start a mission; close the app; reopen and recover the same goal, mode and selected context.
2. Import a compatible local model. Invalid extension, empty/small file or failed replacement must not overwrite a working model.
3. Ask a local question. Show genuine loading/streaming states only while native work is underway, persist the question before generation and save the assistant response to the same mission after success.
4. Reopen a mission and reconstruct a bounded recent local chat history in order.
5. Lock during generation: cancel/stop generation, close native resources safely and clear sensitive in-memory workspace state. Do not commit a partial response as complete.
6. Removing weights preserves encrypted mission conversations. Replacing a model closes the old runtime first.
7. Select library sources, inspect a specialist brief and verify that only selected records plus explicit metadata are included.
8. Share an external response back and save it as linked mission work. A subsequent local turn can compare it with other linked results.
9. Backup/restore preserves mission mode, context links, provenance and parent links; older backups without optional fields remain readable.
10. Light/dark/system themes, increased system font sizes, TalkBack, touch targets and small-screen scrolling remain usable.
11. The UI never claims an external provider is connected or working unless the user has actually invoked it. A model file being installed does not prove it can initialize.

## What follows after MVP

### 1. Verify the local foundation

Run CI and device checks. Benchmark two small supported models on the target phone for memory, first-token latency, steady-state tokens/sec, battery/heat, multilingual usefulness and source-grounding. Add a model compatibility/requirements display based on metadata where available; do not hide failures behind generic success UI.

### 2. Make parallel workers real

Add a provider-neutral worker interface and provider adapters where official APIs/credentials are available. Run independent proposal calls concurrently, preserve every transcript and execution status, allow cancellation per worker, and attach evidence and actual test results. Handoffs through native apps remain user-driven unless the integration supports reliable automation.

### 3. Bounded council

Independent draft → cross-critique → rebuttal/revision → judge against task-specific criteria. Use budgets and max rounds. Preserve unresolved disagreement. A test result or corroborated source should outweigh model confidence or a vote count.

### 4. Visible browser workbench

A controlled WebView/session that shows actions and sources, begins with public pages, validates data extraction and saves versioned recipes. Login, CAPTCHA, blocked interactions and destructive actions should halt for user input, not be bypassed.

### 5. Reusable missions and skills

Make proven workflows editable/versioned and re-run them with explicit success criteria. The local model can suggest a decomposition, relevant records or a recipe change, but the user reviews any material change before it runs.

## Non-negotiables

- Original sources and derived model output remain distinguishable.
- User-selected context is inspectable and bounded.
- There is no silent external disclosure or pretend activity.
- A result is not “verified” without an actual check.
- The runtime is replaceable; SynthOS owns the mission and context.
- Failures preserve the last working file and the encrypted workspace.
