# Changelog — SynthOS 1.2.0

## Product shift

- Replaced the disconnected Council destination with a mission-first three-destination structure: Work, Library and Settings.
- Added the local SynthOS conversation inside a mission, where it can use the goal, selected context and linked specialist results.
- Context selection is now durable mission data and is included in backups; deleting a source removes stale context links.

## On-device intelligence

- Added an adapter around Google's LiteRT-LM Android Kotlin runtime using a user-imported `.litertlm` model file and CPU backend.
- Model weights remain outside the APK and are copied into private app storage through Android's document picker. Import is size-bounded; replacement is staged so a failed move can preserve/restore the prior model.
- Added streaming response UI, saved local user/assistant turns, bounded prior-history reconstruction, context compilation and model lifecycle cancellation when the workspace locks or the model changes.
- Local prompts expressly distinguish supplied evidence from unverified specialist claims and forbid claims of web/app access.

## Product quality

- Added unit tests for local chat-history order, selected sources, linked returned work, mission context and convergence language.
- Expanded product-direction, design/motion and QA documentation; documented that external provider concurrency, a browser automation runtime and on-device performance verification are not shipped yet.
- Updated Kotlin and Compose Gradle plugins to Kotlin 2.4.21 to align with LiteRT-LM 0.18.0's Kotlin 2.4 metadata. Existing GitHub Actions ZIP/YAML workflow and `synthos-pocket-debug-apk` artifact contract are preserved.

## Verification status

- Pure Kotlin domain checks can be run locally; Android Gradle build, lint and APK creation have not been claimed as passing in this environment because the Android SDK/dependency downloads are unavailable. GitHub Actions and physical-device tests remain required.
