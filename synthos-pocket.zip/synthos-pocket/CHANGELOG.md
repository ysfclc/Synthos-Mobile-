# Changelog — SynthOS 1.4.0

## Capture-first and attachment intake

- Reframed the primary Work surface around Quick capture and a reviewable Inbox while retaining Missions as the durable work-continuity layer.
- Added Android `ACTION_SEND_MULTIPLE` and URI-stream handling for text, links, images, PDFs and other file shares.
- Added bounded attachment import: up to five items, 2 MB per item and 6 MB combined. Filenames, MIME types and reported sizes are visible before saving. URI streams are copied only after explicit user confirmation; a failed read saves nothing.
- Added encrypted-record attachment storage and backup schema v2; schema v1 backups remain readable.
- Increased the portable backup format ceiling to 20 MB to accommodate the bounded attachment payloads.
- Fixed the stale Settings version footer and incremented Android version code/name to 5 / 1.4.0.

## Verification status

- Archive structure, checksum generation and source-level checks are performed as part of this delivery.
- Android compilation, lint, emulator/device tests and local model inference must be executed in GitHub Actions/on-device; this editing runtime cannot download Gradle or install Android SDK packages.

---

# Changelog — SynthOS 1.3.0

## Connected sessions and one-tap onboarding

- Added a curated one-tap model library for public LiteRT-LM Qwen3 0.6B INT4, 0.6B INT8 and 1.7B INT4 models. Downloads stay in private storage, report progress, support cancellation, check for truncated downloads, check free space and preserve an earlier working file during replacement. Installed models can be switched or removed individually; custom imported models remain available too.
- Added an optional draggable floating capture bubble with explicit overlay and notification permissions and an ongoing notification. It brings copied text into SynthOS for review and does not save it automatically; stopping it from the notification persists the off state.
- Specialist handoff briefs are now saved to the mission before Android's system destination chooser opens. Android reports the chosen destination, and SynthOS records it against the tracked session. Imported chat transcripts can become missions with the source conversation attached; prompt compilation prioritizes external session context when resuming.
- Updated product/QA docs and added a regression test for preserving tracked external session context in a resumed mission.

## Product shift

- Replaced the disconnected Council destination with a mission-first three-destination structure: Work, Library and Settings.
- Added the local SynthOS conversation inside a mission, where it can use the goal, selected context and linked specialist results.
- Context selection is now durable mission data and is included in backups; deleting a source removes stale context links.

## On-device intelligence

- Added an adapter around Google's LiteRT-LM Android Kotlin runtime using a user-imported `.litertlm` model file and CPU backend.
- Model weights remain outside the APK and are copied into private app storage through Android's document picker. Import is size-bounded; replacement is staged so a failed move can preserve/restore the prior model.
- Added streaming response UI, saved local user/assistant turns, bounded prior-history reconstruction, context compilation and model lifecycle cancellation when the workspace locks or the model changes.
- Local prompts expressly distinguish supplied evidence from unverified specialist claims and forbid claims of web/app access.

## Product quality

- Added unit tests for local chat-history order, selected sources, linked returned work, mission context and convergence language.
- Expanded product-direction, design/motion and QA documentation; documented that external provider concurrency, a browser automation runtime and on-device performance verification are not shipped yet.
- Updated Kotlin and Compose Gradle plugins to Kotlin 2.4.21 to align with LiteRT-LM 0.18.0's Kotlin 2.4 metadata. Existing GitHub Actions ZIP/YAML workflow and `synthos-pocket-debug-apk` artifact contract are preserved.

## Verification status

- Pure Kotlin domain checks can be run locally; Android Gradle build, lint and APK creation have not been claimed as passing in this environment because the Android SDK/dependency downloads are unavailable. GitHub Actions and physical-device tests remain required.
