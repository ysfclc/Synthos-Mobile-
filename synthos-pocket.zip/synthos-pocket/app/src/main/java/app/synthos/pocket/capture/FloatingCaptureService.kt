package app.synthos.pocket.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import app.synthos.pocket.MainActivity
import app.synthos.pocket.R
import kotlin.math.abs

/** User-enabled, draggable overlay that opens SynthOS capture from any app. */
class FloatingCaptureService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("synthos-floating-capture", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
            removeBubble()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        // A sticky restart is allowed only while the user-enabled preference remains on.
        // This prevents an OS restart from resurrecting a bubble after it was switched off.
        val enabled = getSharedPreferences("synthos-floating-capture", MODE_PRIVATE).getBoolean("enabled", false)
        if (!enabled) {
            removeBubble()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "S"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(39, 78, 59)) }
            elevation = 12f
            contentDescription = "Capture to SynthOS"
            setOnClickListener {
                val launch = Intent(this@FloatingCaptureService, MainActivity::class.java).apply {
                    action = ACTION_CAPTURE
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(launch)
            }
        }
        val params = WindowManager.LayoutParams(
            dp(54), dp(54),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(220)
        }
        var startX = 0f
        var startY = 0f
        var initialX = 0
        var initialY = 0
        var dragged = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = params.x; initialY = params.y; dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (startX - event.rawX).toInt()
                    val dy = (event.rawY - startY).toInt()
                    if (abs(dx) > dp(5) || abs(dy) > dp(5)) dragged = true
                    if (dragged) {
                        params.x = (initialX + dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        runCatching { windowManager?.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) view.performClick()
                    true
                }
                else -> false
            }
        }
        // The view's touch handler owns taps as well as dragging.
        runCatching {
            windowManager?.addView(view, params)
            bubble = view
            layoutParams = params
        }.onFailure { stopSelf() }
    }

    private fun removeBubble() {
        bubble?.let { view -> runCatching { windowManager?.removeView(view) } }
        bubble = null
        layoutParams = null
        windowManager = null
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 25, Intent(this, FloatingCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 26, Intent(this, MainActivity::class.java).setAction(ACTION_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_synthos_logo)
            .setContentTitle("SynthOS floating capture is on")
            .setContentText("Tap the floating S bubble to bring content into SynthOS.")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .addAction(0, "Stop bubble", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Floating capture", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the user-enabled SynthOS capture bubble available across apps."
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removeBubble()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "app.synthos.pocket.capture.START"
        const val ACTION_STOP = "app.synthos.pocket.capture.STOP"
        const val ACTION_CAPTURE = "app.synthos.pocket.capture.OPEN"
        private const val CHANNEL_ID = "synthos-floating-capture"
        private const val NOTIFICATION_ID = 4817
    }
}
