package app.synthos.pocket.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import app.synthos.pocket.data.Capture
import app.synthos.pocket.data.CaptureCodec
import app.synthos.pocket.data.CaptureKind
import app.synthos.pocket.data.CaptureStatus
import app.synthos.pocket.data.CouncilMode
import app.synthos.pocket.data.PromptComposer
import app.synthos.pocket.data.WorkspaceState
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private enum class MainTab(val label: String) { TODAY("Today"), LIBRARY("Library"), COUNCIL("Council"), SETTINGS("Settings") }

@Composable
fun SynthOsApp(
    unlocked: Boolean,
    authenticationMessage: String?,
    sharedText: String,
    themeMode: ThemeMode,
    onUnlock: () -> Unit,
    onOpenDeviceSecurity: () -> Unit,
    onSharedTextConsumed: () -> Unit,
    onThemeModeChanged: (ThemeMode) -> Unit
) {
    val context = LocalContext.current
    val workspace = remember(context) { WorkspaceState(context.applicationContext) }
    var tab by rememberSaveable { mutableStateOf(MainTab.TODAY) }
    var quickDraft by remember { mutableStateOf("") }
    var quickKindName by rememberSaveable { mutableStateOf(CaptureKind.IDEA.name) }
    var quickSource by rememberSaveable { mutableStateOf("Quick capture") }
    var editingCapture by remember { mutableStateOf<Capture?>(null) }
    var showExportWarning by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(unlocked) {
        if (unlocked) {
            if (!workspace.isLoaded) workspace.load()
        } else {
            workspace.lock()
            quickDraft = ""
            editingCapture = null
            showExportWarning = false
        }
    }
    if (!unlocked) {
        LockScreen(authenticationMessage, onUnlock, onOpenDeviceSecurity)
        return
    }
    val snackbar = remember { SnackbarHostState() }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val notify: (String) -> Unit = { message -> scope.launchInSnackbar(snackbar, message) }

    LaunchedEffect(sharedText) {
        if (sharedText.isNotBlank()) {
            quickDraft = sharedText.take(50_000)
            quickSource = "Android share"
            tab = MainTab.TODAY
            onSharedTextConsumed()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val json = CaptureCodec.encode(workspace.items)
                val output = context.contentResolver.openOutputStream(uri) ?: error("Android couldn't open the selected export destination.")
                output.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            }.onSuccess { notify("Backup exported. Keep it somewhere private.") }
                .onFailure { notify(it.message ?: "The backup could not be exported.") }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val input = context.contentResolver.openInputStream(uri) ?: error("Android couldn't open that file.")
                val json = input.use { readBoundedText(it, CaptureCodec.MAX_BACKUP_BYTES) }
                workspace.importBackup(json)
            }.onSuccess { count ->
                notify(if (count == 0) "No new items found. Existing items were kept." else "$count item${if (count == 1) "" else "s"} restored.")
            }.onFailure { notify(it.message ?: "That backup couldn't be restored.") }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                MainTab.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = tab == destination,
                        onClick = { tab = destination },
                        icon = {
                            Icon(
                                imageVector = when (destination) {
                                    MainTab.TODAY -> Icons.Outlined.Home
                                    MainTab.LIBRARY -> Icons.Outlined.Search
                                    MainTab.COUNCIL -> Icons.Outlined.AccountTree
                                    MainTab.SETTINGS -> Icons.Outlined.Settings
                                },
                                contentDescription = destination.label
                            )
                        },
                        label = { Text(destination.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                !workspace.isLoaded -> LoadingScreen()
                workspace.error != null -> StorageErrorScreen(workspace.error.orEmpty(), workspace::load)
                else -> when (tab) {
                    MainTab.TODAY -> TodayScreen(
                        workspace = workspace,
                        draft = quickDraft,
                        onDraftChanged = { value ->
                            if (value != quickDraft) quickSource = "Quick capture"
                            quickDraft = value
                        },
                        sourceLabel = quickSource,
                        kindName = quickKindName,
                        onKindChanged = { quickKindName = it },
                        onEdit = { editingCapture = it },
                        onOpenLibrary = { tab = MainTab.LIBRARY },
                        onNotify = notify
                    )
                    MainTab.LIBRARY -> LibraryScreen(workspace, onEdit = { editingCapture = it })
                    MainTab.COUNCIL -> CouncilScreen(workspace, onNotify = notify)
                    MainTab.SETTINGS -> SettingsScreen(
                        themeMode = themeMode,
                        onThemeModeChanged = onThemeModeChanged,
                        onExport = { showExportWarning = true },
                        onImport = { importLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }
                    )
                }
            }
        }
    }

    if (editingCapture != null && workspace.error == null) {
        CaptureEditorDialog(
            capture = editingCapture!!,
            onDismiss = { editingCapture = null },
            onSave = { edited ->
                val saved = workspace.update(edited)
                if (saved) {
                    editingCapture = null
                    notify("Changes saved securely.")
                } else notify(workspace.operationMessage ?: "The change could not be saved.")
            },
            onDelete = { id ->
                val deleted = workspace.delete(id)
                if (deleted) {
                    editingCapture = null
                    notify("Item deleted.")
                } else notify(workspace.operationMessage ?: "The item could not be deleted.")
            }
        )
    }

    if (showExportWarning) {
        AlertDialog(
            onDismissRequest = { showExportWarning = false },
            icon = { Icon(Icons.Outlined.FileDownload, contentDescription = null, tint = warningSemanticColor()) },
            title = { Text("Export a backup?") },
            text = { Text("The chosen JSON backup is not encrypted so you can move it between apps and devices. Anyone who can read that file can read its contents. Save it to a trusted location.") },
            confirmButton = {
                Button(onClick = {
                    showExportWarning = false
                    exportLauncher.launch("synthos-backup.json")
                }) { Text("Choose location") }
            },
            dismissButton = { TextButton(onClick = { showExportWarning = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun LockScreen(message: String?, onUnlock: () -> Unit, onOpenDeviceSecurity: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 28.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(76.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(38.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("SynthOS", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("Your work, connected.", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text("A private workspace for the ideas, sources and decisions you want to keep.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Encrypted on this device", style = MaterialTheme.typography.titleMedium)
                    Text("Unlock with a strong biometric or your device lock. Your workspace doesn't need a cloud account.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (!message.isNullOrBlank()) {
            Spacer(Modifier.height(16.dp))
            Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium) {
                Text(message, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onUnlock, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
            Icon(Icons.Outlined.Lock, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("Unlock workspace")
        }
        TextButton(onClick = onOpenDeviceSecurity, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
            Text("Device security settings")
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            CircularProgressIndicator()
            Text("Unlocking your workspace…", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StorageErrorScreen(message: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(16.dp))
        Text("Workspace not available", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
            Text("Retry loading")
        }
        Spacer(Modifier.height(8.dp))
        Text("SynthOS will not replace a workspace it cannot read.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TodayScreen(
    workspace: WorkspaceState,
    draft: String,
    onDraftChanged: (String) -> Unit,
    sourceLabel: String,
    kindName: String,
    onKindChanged: (String) -> Unit,
    onEdit: (Capture) -> Unit,
    onOpenLibrary: () -> Unit,
    onNotify: (String) -> Unit
) {
    val inboxCount = workspace.items.count { it.status == CaptureStatus.INBOX }
    val activeCount = workspace.items.count { it.status == CaptureStatus.ACTIVE }
    val recent = workspace.items.filter { it.status == CaptureStatus.INBOX || it.status == CaptureStatus.ACTIVE }.take(5)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        BrandHeader()
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Your work, connected.", style = MaterialTheme.typography.headlineLarge)
            Text("Catch the signal. Keep the context. Move forward.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard("Inbox", inboxCount.toString(), Icons.Outlined.BookmarkBorder, Modifier.weight(1f))
            MetricCard("In progress", activeCount.toString(), Icons.Outlined.TaskAlt, Modifier.weight(1f))
            MetricCard("Kept", workspace.items.count { it.status == CaptureStatus.DONE }.toString(), Icons.Outlined.CheckCircleOutline, Modifier.weight(1f))
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(34.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Lightbulb, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer) }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Quick capture", style = MaterialTheme.typography.titleLarge)
                        Text("Private, encrypted, and ready to use offline.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                OutlinedTextField(
                    value = draft,
                    onValueChange = { onDraftChanged(it.take(50_000)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 124.dp),
                    placeholder = { Text("An idea, a link, a decision, something to follow up…") },
                    minLines = 3,
                    maxLines = 7,
                    shape = MaterialTheme.shapes.medium
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CaptureKind.entries.forEach { kind ->
                        FilterChip(
                            selected = kindName == kind.name,
                            onClick = { onKindChanged(kind.name) },
                            label = { Text(kind.label) }
                        )
                    }
                }
                Button(
                    onClick = {
                        val kind = CaptureKind.entries.firstOrNull { it.name == kindName } ?: CaptureKind.IDEA
                        val ok = workspace.add(draft, kind, sourceLabel)
                        if (ok) {
                            onDraftChanged("")
                            onNotify("Saved to your encrypted inbox.")
                        } else onNotify(workspace.operationMessage ?: "Add some text and try again.")
                    },
                    enabled = draft.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
                ) {
                    Icon(Icons.Outlined.BookmarkBorder, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save to inbox")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Pick up where you left off", style = MaterialTheme.typography.titleLarge)
                Text("Your active context, not another feed.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onOpenLibrary) { Text("View all") }
        }
        if (recent.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.CloudOff,
                title = "A quiet workspace is a good start",
                body = "Capture something above, or share text from another app using Android's Share menu."
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                recent.forEach { capture -> CaptureCard(capture, onClick = { onEdit(capture) }) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text("S", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("SynthOS", style = MaterialTheme.typography.titleLarge)
            Text("PERSONAL INTELLIGENCE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.1.sp)
        }
        Spacer(Modifier.weight(1f))
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(14.dp))
                Text("Local", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun LibraryScreen(workspace: WorkspaceState, onEdit: (Capture) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedStatus by rememberSaveable { mutableStateOf("All") }
    val statuses = listOf("All") + CaptureStatus.entries.map { it.label }
    val filtered = workspace.items.filter { capture ->
        val matchesQuery = query.isBlank() || listOf(capture.title, capture.content, capture.sourceLabel, capture.kind.label).any { it.contains(query, ignoreCase = true) }
        val matchesStatus = selectedStatus == "All" || capture.status.label == selectedStatus
        matchesQuery && matchesStatus
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            PageHeader("Library", "Find the source, idea or decision you saved.")
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(300) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                placeholder = { Text("Search titles, notes and sources") },
                shape = MaterialTheme.shapes.large
            )
        }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                statuses.forEach { status ->
                    FilterChip(selected = selectedStatus == status, onClick = { selectedStatus = status }, label = { Text(status) })
                }
            }
        }
        item { Text("${filtered.size} item${if (filtered.size == 1) "" else "s"}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (filtered.isEmpty()) {
            item {
                EmptyState(
                    icon = if (query.isBlank()) Icons.Outlined.MenuBook else Icons.Outlined.Search,
                    title = if (query.isBlank()) "Nothing here yet" else "No matches",
                    body = if (query.isBlank()) "Capture something on Today, or share selected text from any app." else "Try a shorter search or another status filter."
                )
            }
        }
        items(filtered, key = { it.id }) { capture -> CaptureCard(capture, onClick = { onEdit(capture) }) }
    }
}

@Composable
private fun CouncilScreen(workspace: WorkspaceState, onNotify: (String) -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var mode by rememberSaveable { mutableStateOf(CouncilMode.SYNTHESIZE.name) }
    val selected = workspace.items.filter { it.id in workspace.selectedIds }
    val available = workspace.items.filter { it.status != CaptureStatus.ARCHIVED }
    val currentMode = CouncilMode.entries.firstOrNull { it.name == mode } ?: CouncilMode.SYNTHESIZE
    val packet = runCatching { PromptComposer.compose(selected, currentMode) }.getOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHeader("Council", "Build a source-aware brief for the AI tools you already use.") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(26.dp))
                    Text("Your context. Their intelligence.", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("SynthOS prepares a structured handoff with source labels, dates, boundaries and a clear task. You choose which app receives it. This version does not call AI providers in the background.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        item { Text("1 · Choose the job", style = MaterialTheme.typography.titleMedium) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CouncilMode.entries.forEach { option ->
                    val isSelected = option == currentMode
                    Card(
                        onClick = { mode = option.name },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            RadioDot(isSelected)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(option.label, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    when (option) {
                                        CouncilMode.SYNTHESIZE -> "Combine the useful signal and keep disagreements visible."
                                        CouncilMode.RESEARCH -> "Find evidence gaps and define the next questions."
                                        CouncilMode.CHALLENGE -> "Stress-test assumptions and look for failure modes."
                                        CouncilMode.PLAN -> "Turn context into concrete, prioritized steps."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("2 · Add context", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text("${selected.size}/${PromptComposer.MAX_SELECTED_ITEMS}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (available.isEmpty()) {
            item {
                EmptyState(Icons.Outlined.BookmarkBorder, "Your context starts here", "Save an idea, question or source on the Today screen, then return here to prepare a brief.")
            }
        } else {
            items(available, key = { "select-${it.id}" }) { capture ->
                val isChecked = capture.id in workspace.selectedIds
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, if (isChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Checkbox(checked = isChecked, onCheckedChange = { checked ->
                            val wasAtLimit = workspace.selectedIds.size >= PromptComposer.MAX_SELECTED_ITEMS
                            workspace.toggleSelected(capture.id, checked)
                            if (checked && !isChecked && wasAtLimit) onNotify("Briefs can include up to ${PromptComposer.MAX_SELECTED_ITEMS} items.")
                        })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(capture.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${capture.kind.label} · ${capture.sourceLabel}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            if (workspace.selectedIds.isNotEmpty()) {
                TextButton(onClick = workspace::clearSelection) { Text("Clear selection") }
            }
        }
        item { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant) }
        item { Text("3 · Send the brief", style = MaterialTheme.typography.titleMedium) }
        item {
            Text("The brief is composed locally. Sharing it sends the selected material to whichever app you choose in Android's Sharesheet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            Button(
                onClick = {
                    val text = packet ?: return@Button
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "SynthOS · ${currentMode.label}")
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    runCatching { context.startActivity(Intent.createChooser(shareIntent, "Send SynthOS brief")) }
                        .onFailure { onNotify("No app is available to receive this brief.") }
                },
                enabled = packet != null,
                modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
            ) {
                Icon(Icons.Outlined.Share, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Share brief with an AI app")
            }
        }
        item {
            OutlinedButton(
                onClick = {
                    packet?.let {
                        clipboard.setText(AnnotatedString(it))
                        onNotify("Brief copied. Paste it into the AI tool you choose.")
                    }
                },
                enabled = packet != null,
                modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)
            ) {
                Icon(Icons.Outlined.ContentCopy, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Copy context packet")
            }
        }
        if (selected.isNotEmpty()) {
            item {
                Text("Included: ${selected.joinToString { it.title }.take(220)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun RadioDot(selected: Boolean) {
    Surface(
        shape = CircleShape,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.size(20.dp)
    ) {
        if (selected) Box(Modifier.padding(5.dp), contentAlignment = Alignment.Center) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(10.dp)) {}
        }
    }
}

@Composable
private fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeModeChanged: (ThemeMode) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        PageHeader("Settings", "Private by design. No account, ads or analytics.")
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Encrypted local workspace", style = MaterialTheme.typography.titleMedium)
                        Text("AES-256-GCM encryption with a non-exportable Android Keystore key. Biometric or device-lock authentication gates access.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Offline by default", style = MaterialTheme.typography.titleMedium)
                        Text("This build has no internet permission. Data leaves the workspace only when you explicitly share or export it.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleLarge)
            Text("Choose how SynthOS looks on this device.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = themeMode == mode,
                        onClick = { onThemeModeChanged(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Backup and restore", style = MaterialTheme.typography.titleLarge)
            Text("Backups are portable JSON. Import adds only items whose IDs are not already in your workspace.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                Icon(Icons.Outlined.FileDownload, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Export backup")
            }
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp)) {
                Icon(Icons.Outlined.FileUpload, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Restore from backup")
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Outlined.PhoneAndroid, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Built for your workflow", style = MaterialTheme.typography.titleMedium)
                    Text("Capture from any app, search your own context, and prepare research or challenge briefs for the AI tools you already use. No API key or subscription is required.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("SynthOS Pocket · 1.0.0", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CaptureEditorDialog(
    capture: Capture,
    onDismiss: () -> Unit,
    onSave: (Capture) -> Unit,
    onDelete: (String) -> Unit
) {
    var title by remember(capture.id) { mutableStateOf(capture.title) }
    var content by remember(capture.id) { mutableStateOf(capture.content) }
    var kind by remember(capture.id) { mutableStateOf(capture.kind) }
    var status by remember(capture.id) { mutableStateOf(capture.status) }
    var confirmDelete by remember(capture.id) { mutableStateOf(false) }
    var validationError by remember(capture.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit item") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it.take(180) }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = false)
                OutlinedTextField(value = content, onValueChange = { content = it.take(50_000) }, label = { Text("Content") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), minLines = 4, maxLines = 12)
                Text("Type", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CaptureKind.entries.forEach { option -> FilterChip(selected = kind == option, onClick = { kind = option }, label = { Text(option.label) }) }
                }
                Text("Status", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CaptureStatus.entries.forEach { option -> FilterChip(selected = status == option, onClick = { status = option }, label = { Text(option.label) }) }
                }
                Text("Source: ${capture.sourceLabel}${capture.sourceUrl?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Created ${formatDate(capture.createdAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (validationError != null) Text(validationError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank() || content.isBlank()) validationError = "Add a title and some content before saving."
                else onSave(capture.copy(title = title.trim(), content = content.trim(), kind = kind, status = status))
            }) { Text("Save changes") }
        },
        dismissButton = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete item", tint = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    )
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            icon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete this item?") },
            text = { Text("This permanently removes the item from the encrypted workspace. Export a backup first if you may need it later.") },
            confirmButton = { Button(onClick = { confirmDelete = false; onDelete(capture.id) }) { Text("Delete permanently") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep item") } }
        )
    }
}

@Composable
private fun CaptureCard(capture: Capture, onClick: () -> Unit) {
    val darkSurface = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val statusTint = when (capture.status) {
        CaptureStatus.DONE -> if (darkSurface) SynthSemantic.successDark else SynthSemantic.successLight
        CaptureStatus.ACTIVE -> if (darkSurface) SynthSemantic.infoDark else SynthSemantic.infoLight
        CaptureStatus.ARCHIVED -> MaterialTheme.colorScheme.onSurfaceVariant
        CaptureStatus.INBOX -> MaterialTheme.colorScheme.primary
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(kindIcon(capture.kind), contentDescription = capture.kind.label, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(21.dp))
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(capture.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(capture.content.replace(Regex("\\s+"), " "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(capture.kind.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text(capture.status.label, style = MaterialTheme.typography.labelSmall, color = statusTint)
                    Text("·", color = MaterialTheme.colorScheme.outline)
                    Text(formatDate(capture.updatedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (capture.sourceUrl != null) Text(capture.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(30.dp))
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun kindIcon(kind: CaptureKind): ImageVector = when (kind) {
    CaptureKind.IDEA -> Icons.Outlined.Lightbulb
    CaptureKind.RESEARCH -> Icons.Outlined.Search
    CaptureKind.TASK -> Icons.Outlined.TaskAlt
    CaptureKind.REFERENCE -> Icons.Outlined.MenuBook
    CaptureKind.DECISION -> Icons.Outlined.CheckCircleOutline
}

@Composable
private fun warningSemanticColor() = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) SynthSemantic.warningDark else SynthSemantic.warningLight

private fun formatDate(timestamp: Long): String = try {
    DateTimeFormatter.ofPattern("d MMM yyyy").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(timestamp))
} catch (_: Exception) { "Saved" }

private fun readBoundedText(input: InputStream, limit: Int): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    while (true) {
        val read = input.read(buffer)
        if (read < 0) break
        total += read
        require(total <= limit) { "The selected file exceeds the 10 MB import limit." }
        output.write(buffer, 0, read)
    }
    return output.toString(Charsets.UTF_8.name())
}

private fun kotlinx.coroutines.CoroutineScope.launchInSnackbar(host: SnackbarHostState, message: String) {
    launch { host.showSnackbar(message) }
}
