package app.synthos.pocket

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.synthos.pocket.ui.SynthOsApp
import app.synthos.pocket.ui.SynthOsTheme
import app.synthos.pocket.ui.ThemeMode
import app.synthos.pocket.capture.FloatingCaptureService
import app.synthos.pocket.data.IncomingAttachment
import app.synthos.pocket.data.SharedAttachmentImport

class MainActivity : FragmentActivity() {
    private val unlocked = mutableStateOf(false)
    private val authenticationMessage = mutableStateOf<String?>(null)
    private val sharedDraft = mutableStateOf("")
    private val sharedAttachments = mutableStateOf<List<IncomingAttachment>>(emptyList())
    private val floatingCaptureRequested = mutableStateOf(false)
    private val shareTargetUpdate = mutableStateOf<Pair<String, String>?>(null)
    private val floatingCaptureEnabled = mutableStateOf(false)
    private var backgroundedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Prevent sensitive workspace snapshots from appearing in screenshots or recents.
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        consumeSharedIntent(intent)
        val preferences = getSharedPreferences("synthos-ui", MODE_PRIVATE)
        floatingCaptureEnabled.value = getSharedPreferences("synthos-floating-capture", MODE_PRIVATE).getBoolean("enabled", false)
        val selectedTheme = mutableStateOf(ThemeMode.parse(preferences.getString("theme", "SYSTEM")))
        setContent {
            SynthOsTheme(selectedTheme.value) {
                SynthOsApp(
                    unlocked = unlocked.value,
                    authenticationMessage = authenticationMessage.value,
                    sharedText = sharedDraft.value,
                    sharedAttachments = sharedAttachments.value,
                    floatingCaptureRequested = floatingCaptureRequested.value,
                    shareTargetUpdate = shareTargetUpdate.value,
                    floatingCaptureEnabled = floatingCaptureEnabled.value,
                    themeMode = selectedTheme.value,
                    onUnlock = ::authenticate,
                    onOpenDeviceSecurity = ::openDeviceSecurity,
                    onSharedTextConsumed = { sharedDraft.value = ""; sharedAttachments.value = emptyList() },
                    onFloatingCaptureConsumed = { floatingCaptureRequested.value = false },
                    onShareTargetUpdateConsumed = { shareTargetUpdate.value = null },
                    onFloatingCaptureChanged = ::setFloatingCaptureEnabled,
                    onThemeModeChanged = { mode ->
                        selectedTheme.value = mode
                        preferences.edit().putString("theme", mode.name).apply()
                        applyWindowTheme(mode)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeSharedIntent(intent)
    }

    override fun onStop() {
        if (unlocked.value) backgroundedAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (backgroundedAt > 0L && SystemClock.elapsedRealtime() - backgroundedAt >= 60_000L) {
            unlocked.value = false
        }
        backgroundedAt = 0L
        val mode = ThemeMode.parse(getSharedPreferences("synthos-ui", MODE_PRIVATE).getString("theme", "SYSTEM"))
        applyWindowTheme(mode)
        val targetPreferences = getSharedPreferences(app.synthos.pocket.capture.ShareTargetChosenReceiver.PREFERENCES, MODE_PRIVATE)
        val selectedSessionId = targetPreferences.getString(app.synthos.pocket.capture.ShareTargetChosenReceiver.KEY_SESSION_ID, null)
        val selectedTarget = targetPreferences.getString(app.synthos.pocket.capture.ShareTargetChosenReceiver.KEY_TARGET_LABEL, null)
        if (!selectedSessionId.isNullOrBlank() && !selectedTarget.isNullOrBlank()) {
            shareTargetUpdate.value = selectedSessionId to selectedTarget
            targetPreferences.edit().remove(app.synthos.pocket.capture.ShareTargetChosenReceiver.KEY_SESSION_ID).apply()
        }
        val preferences = getSharedPreferences("synthos-floating-capture", MODE_PRIVATE)
        val enabled = preferences.getBoolean("enabled", false)
        if (enabled && Settings.canDrawOverlays(this)) {
            floatingCaptureEnabled.value = true
            runCatching {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, FloatingCaptureService::class.java).setAction(FloatingCaptureService.ACTION_START)
                )
            }.onFailure {
                preferences.edit().putBoolean("enabled", false).apply()
                floatingCaptureEnabled.value = false
            }
        } else {
            if (enabled && !Settings.canDrawOverlays(this)) preferences.edit().putBoolean("enabled", false).apply()
            floatingCaptureEnabled.value = false
        }
    }

    private fun setFloatingCaptureEnabled(enabled: Boolean) {
        val preferences = getSharedPreferences("synthos-floating-capture", MODE_PRIVATE)
        if (!enabled) {
            floatingCaptureEnabled.value = false
            preferences.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, FloatingCaptureService::class.java))
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            // Keep the feature off until Android grants notification permission; the
            // persistent notification is the visible way to stop the overlay later.
            floatingCaptureEnabled.value = false
            preferences.edit().putBoolean("enabled", false).apply()
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS_FOR_CAPTURE)
            return
        }
        floatingCaptureEnabled.value = true
        preferences.edit().putBoolean("enabled", true).apply()
        if (Settings.canDrawOverlays(this)) {
            runCatching {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, FloatingCaptureService::class.java).setAction(FloatingCaptureService.ACTION_START)
                )
            }.onFailure {
                getSharedPreferences("synthos-floating-capture", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
            }
        } else {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                preferences.edit().putBoolean("enabled", false).apply()
                floatingCaptureEnabled.value = false
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS_FOR_CAPTURE) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                setFloatingCaptureEnabled(true)
            } else {
                floatingCaptureEnabled.value = false
                getSharedPreferences("synthos-floating-capture", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
            }
        }
    }

    private fun applyWindowTheme(mode: ThemeMode) {
        val systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val dark = when (mode) {
            ThemeMode.SYSTEM -> systemDark
            ThemeMode.LIGHT -> false
            ThemeMode.DARK -> true
        }
        val barColor = Color.parseColor(if (dark) "#121914" else "#F6F7F2")
        window.statusBarColor = barColor
        window.navigationBarColor = barColor
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    private fun authenticate() {
        val modernAndroid = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(this)

        // Android 11+ supports the combined authenticator bitmask. On Android 8–10,
        // AndroidX requires setDeviceCredentialAllowed(true) instead; don't reject a
        // valid secure device lock merely because no strong biometric is enrolled.
        if (modernAndroid && manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            authenticationMessage.value = "Set up a strong biometric or secure device lock in Android Settings to unlock SynthOS. Your workspace stays encrypted until authentication is available."
            return
        }

        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock SynthOS")
            .setSubtitle("Authenticate to open your encrypted workspace")
        if (modernAndroid) {
            promptInfoBuilder.setAllowedAuthenticators(authenticators)
        } else {
            promptInfoBuilder.setDeviceCredentialAllowed(true)
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticationMessage.value = null
                    unlocked.value = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticationMessage.value = when (errorCode) {
                        BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_NEGATIVE_BUTTON -> "Unlock was cancelled. Your workspace remains protected."
                        else -> "Authentication didn't complete. Try again to open your workspace."
                    }
                }
            }
        )
        try {
            prompt.authenticate(promptInfoBuilder.build())
            authenticationMessage.value = null
        } catch (_: Exception) {
            authenticationMessage.value = "Android couldn't start authentication. Configure a screen lock or strong biometric in Android Settings, then try again."
        }
    }

    private fun openDeviceSecurity() {
        try {
            startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {
                authenticationMessage.value = "Open Android Settings and configure a screen lock or strong biometric, then return here."
            }
        }
    }

    private fun consumeSharedIntent(intent: Intent?) {
        if (intent?.action == FloatingCaptureService.ACTION_CAPTURE) {
            floatingCaptureRequested.value = true
            setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
            return
        }
        if (intent?.action != Intent.ACTION_SEND && intent?.action != Intent.ACTION_SEND_MULTIPLE) return

        val shared = (intent.getCharSequenceExtra(Intent.EXTRA_TEXT)
            ?: intent.getCharSequenceExtra(Intent.EXTRA_HTML_TEXT))?.toString()?.trim().orEmpty()
        val attachments = SharedAttachmentImport.fromIntent(this, intent)
        if (shared.isNotBlank() || attachments.isNotEmpty()) {
            sharedAttachments.value = attachments
            sharedDraft.value = shared.take(50_000)
        }
        // Clear the original Intent after consuming it so a configuration recreation cannot replay a capture.
        setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
    }
    companion object { private const val REQUEST_NOTIFICATIONS_FOR_CAPTURE = 7103 }

}
