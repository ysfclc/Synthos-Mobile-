package app.synthos.pocket.data

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.LogSeverity
import com.google.ai.edge.litertlm.Message
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.EmptyCoroutineContext

data class LocalAiRuntimeState(
    val missionId: String? = null,
    val isGenerating: Boolean = false,
    val preview: String = "",
    val error: String? = null
)

/** Streaming, on-device model runtime. It never makes a network request. */
class LocalAiRuntime(private val cacheDirectory: File) {
    private val mutex = Mutex()
    private val mutableState = MutableStateFlow(LocalAiRuntimeState())
    val state: StateFlow<LocalAiRuntimeState> = mutableState.asStateFlow()
    // Native model calls, cancellation and teardown share one dedicated thread.
    private val modelDispatcher = Executors.newSingleThreadExecutor { task ->
        Thread(task, "synthos-local-ai").apply { isDaemon = true }
    }.asCoroutineDispatcher()
    private val cancellationEpoch = AtomicLong(0L)
    private val requestActive = AtomicBoolean(false)
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var loadedModelPath: String? = null
    private var conversationKey: String? = null
    @Volatile private var activeConversation: Conversation? = null

    /**
     * Emits the cumulative response as it is generated, suitable for a streaming UI.
     * Prior turns and the instruction are reconstructed from saved mission records when
     * the mission or its context changes; model weights stay loaded until [close] is called.
     */
    fun streamReply(
        modelFile: File,
        missionId: String,
        systemInstruction: String,
        priorTurns: List<LocalChatTurn>,
        userMessage: String
    ): Flow<String> {
        val requestEpoch = cancellationEpoch.get()
        return flow {
            checkNotCancelled(requestEpoch)
            require(modelFile.isFile && modelFile.length() > 0L) {
                "Install a compatible local model in Settings first."
            }
            require(userMessage.isNotBlank()) { "Write a message before sending." }
            check(requestActive.compareAndSet(false, true)) {
                "SynthOS is already working on another mission. Wait for that reply to finish."
            }
            mutableState.value = LocalAiRuntimeState(missionId = missionId, isGenerating = true)
            try {
                mutex.withLock {
                    ensureEngine(modelFile)
                    checkNotCancelled(requestEpoch)
                    val safeHistory = priorTurns.takeLast(MAX_RESTORED_TURNS).map { turn ->
                        if (turn.isUser) Message.user(turn.content.take(MAX_TURN_CHARS))
                        else Message.model(turn.content.take(MAX_TURN_CHARS))
                    }
                    val key = "$missionId:${systemInstruction.hashCode()}:${safeHistory.hashCode()}"
                    if (conversation == null || conversationKey != key) {
                        conversation?.close()
                        conversation = engine!!.createConversation(
                            ConversationConfig(
                                systemInstruction = Contents.of(systemInstruction.take(MAX_SYSTEM_CHARS)),
                                initialMessages = safeHistory
                            )
                        )
                        conversationKey = key
                    }
                    val output = StringBuilder()
                    checkNotCancelled(requestEpoch)
                    activeConversation = conversation
                    try {
                        conversation!!.sendMessageAsync(userMessage.trim().take(MAX_TURN_CHARS)).collect { chunk ->
                            checkNotCancelled(requestEpoch)
                            output.append(chunk.toString())
                            mutableState.value = LocalAiRuntimeState(missionId, true, output.toString())
                            emit(output.toString())
                        }
                        checkNotCancelled(requestEpoch)
                    } finally {
                        if (activeConversation === conversation) activeConversation = null
                    }
                }
                mutableState.value = LocalAiRuntimeState(missionId = missionId)
            } catch (cancelled: CancellationException) {
                mutableState.value = if (cancellationEpoch.get() == requestEpoch) {
                    LocalAiRuntimeState(missionId = missionId)
                } else {
                    LocalAiRuntimeState()
                }
                throw cancelled
            } catch (error: Throwable) {
                mutableState.value = if (cancellationEpoch.get() == requestEpoch) {
                    LocalAiRuntimeState(
                        missionId = missionId,
                        error = error.message?.take(500) ?: "Local generation failed. Check the model format and available memory."
                    )
                } else {
                    LocalAiRuntimeState()
                }
                throw error
            } finally {
                requestActive.set(false)
            }
        }.flowOn(modelDispatcher)
    }

    /** Ask the native decoder to stop promptly when the app locks. */
    fun requestCancel() {
        cancellationEpoch.incrementAndGet()
        // Clear any streamed private preview immediately, even if native cancellation takes time.
        mutableState.value = LocalAiRuntimeState()
        // The epoch also stops a request that is still initializing and has no Conversation yet.
        modelDispatcher.dispatch(EmptyCoroutineContext) {
            runCatching { activeConversation?.cancelProcess() }
        }
    }

    /** Close native resources on a background thread after the caller has requested cancellation. */
    suspend fun close() = withContext(modelDispatcher) {
        mutex.withLock { closeLocked() }
    }

    private fun checkNotCancelled(requestEpoch: Long) {
        if (cancellationEpoch.get() != requestEpoch) {
            throw CancellationException("Local generation stopped because the workspace was locked or the model changed.")
        }
    }

    private fun ensureEngine(modelFile: File) {
        val requestedPath = modelFile.absolutePath
        if (engine != null && loadedModelPath == requestedPath) return
        closeLocked()
        // LiteRT-LM requires cacheDir to exist before Engine is constructed.
        // Android's cacheDir/litertlm child is not created automatically.
        if (!cacheDirectory.exists() && !cacheDirectory.mkdirs()) {
            throw IllegalStateException(
                "Cannot create the local AI cache directory: ${cacheDirectory.absolutePath}"
            )
        }
        check(cacheDirectory.isDirectory) {
            "Local AI cache path is not a directory: ${cacheDirectory.absolutePath}"
        }
        check(cacheDirectory.canWrite()) {
            "Local AI cache directory is not writable: ${cacheDirectory.absolutePath}"
        }
        Engine.setNativeMinLogSeverity(LogSeverity.ERROR)
        val newEngine = Engine(
            EngineConfig(
                modelPath = requestedPath,
                backend = Backend.CPU(),
                cacheDir = cacheDirectory.absolutePath
            )
        )
        try {
            newEngine.initialize()
            engine = newEngine
            loadedModelPath = requestedPath
        } catch (error: Throwable) {
            runCatching { newEngine.close() }
            throw error
        }
    }

    private fun closeLocked() {
        runCatching { conversation?.close() }
        conversation = null
        activeConversation = null
        conversationKey = null
        runCatching { engine?.close() }
        engine = null
        loadedModelPath = null
    }

    private companion object {
        const val MAX_RESTORED_TURNS = 10
        const val MAX_TURN_CHARS = 3_000
        const val MAX_SYSTEM_CHARS = 12_000
    }
}
