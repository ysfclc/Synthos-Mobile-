package app.synthos.pocket.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import java.util.Base64
import java.io.ByteArrayOutputStream
import java.util.UUID

/** Metadata for a URI temporarily granted by Android's Sharesheet. Never persisted as a URI alone. */
data class IncomingAttachment(
    val uri: Uri,
    val fileName: String,
    val mimeType: String,
    val reportedByteLength: Long?,
    /** Count of additional shared URIs intentionally omitted by the bounded importer. */
    val omittedCount: Int = 0
)

/** A bounded attachment copied into the encrypted workspace record, not a fragile content:// reference. */
data class CaptureAttachment(
    val id: String,
    val fileName: String,
    val mimeType: String,
    val byteLength: Long,
    /** Base64 is used only as the JSON transport representation; the on-device store encrypts the full record. */
    val dataBase64: String
)

object SharedAttachmentImport {
    const val MAX_ATTACHMENTS = 5
    const val MAX_ATTACHMENT_BYTES = 2 * 1024 * 1024
    const val MAX_TOTAL_BYTES = 6 * 1024 * 1024

    /** Extracts supported content URIs from both modern and legacy Sharesheet payload shapes. */
    fun fromIntent(context: Context, intent: Intent?): List<IncomingAttachment> {
        if (intent == null || (intent.action != Intent.ACTION_SEND && intent.action != Intent.ACTION_SEND_MULTIPLE)) return emptyList()
        val uris = LinkedHashSet<Uri>()
        intent.data?.let(uris::add)
        intent.clipData?.let { clip ->
            for (index in 0 until minOf(clip.itemCount, 100)) {
                clip.getItemAt(index).uri?.let(uris::add)
            }
        }
        @Suppress("DEPRECATION")
        when (intent.action) {
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                (intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let(uris::add)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.forEach(uris::add)
            }
        }
        val allUris = uris.toList()
        val omittedCount = (allUris.size - MAX_ATTACHMENTS).coerceAtLeast(0)
        return allUris.take(MAX_ATTACHMENTS).mapIndexedNotNull { index, uri ->
            runCatching {
                var name = "Attachment ${index + 1}"
                var size: Long? = null
                runCatching {
                    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (nameIndex >= 0) cursor.getString(nameIndex)?.takeIf(String::isNotBlank)?.let { name = it }
                            if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex).takeIf { it >= 0L }?.let { size = it }
                        }
                    }
                }
                IncomingAttachment(
                    uri = uri,
                    fileName = name.replace(Regex("[\\r\\n\\u0000]"), "_").take(240).ifBlank { "Attachment ${index + 1}" },
                    mimeType = (runCatching { context.contentResolver.getType(uri) }.getOrNull() ?: "application/octet-stream").take(160),
                    reportedByteLength = size,
                    omittedCount = if (index == 0) omittedCount else 0
                )
            }.getOrNull()
        }
    }

    /** Reads only bounded streams, so a hostile/incorrect content provider cannot exhaust memory. */
    fun read(context: Context, incoming: List<IncomingAttachment>): List<CaptureAttachment> {
        require(incoming.size <= MAX_ATTACHMENTS) { "Choose at most $MAX_ATTACHMENTS attachments at once." }
        var total = 0L
        return incoming.map { item ->
            if (item.reportedByteLength != null && item.reportedByteLength > MAX_ATTACHMENT_BYTES) {
                throw IllegalArgumentException("${item.fileName} exceeds the 2 MB per-attachment limit. Share a smaller file.")
            }
            val stream = context.contentResolver.openInputStream(item.uri)
                ?: throw IllegalArgumentException("Android couldn't open ${item.fileName}. Share it again and retry.")
            val bytes = stream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var count: Int
                while (input.read(buffer).also { count = it } >= 0) {
                    if (count == 0) continue
                    if (output.size().toLong() + count > MAX_ATTACHMENT_BYTES) {
                        throw IllegalArgumentException("${item.fileName} exceeds the 2 MB per-attachment limit. Share a smaller file.")
                    }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            total += bytes.size
            if (total > MAX_TOTAL_BYTES) throw IllegalArgumentException("Attachments exceed the 6 MB combined limit. Save fewer or smaller files.")
            if (bytes.isEmpty()) throw IllegalArgumentException("${item.fileName} is empty and was not saved as an attachment.")
            CaptureAttachment(
                id = UUID.randomUUID().toString(),
                fileName = item.fileName.take(240).ifBlank { "Attachment" },
                mimeType = item.mimeType.take(160).ifBlank { "application/octet-stream" },
                byteLength = bytes.size.toLong(),
                dataBase64 = Base64.getEncoder().encodeToString(bytes)
            )
        }
    }
}
