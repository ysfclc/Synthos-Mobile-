package app.synthos.pocket.capture

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Records the destination explicitly chosen in Android's system sharesheet. */
class ShareTargetChosenReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent?) {
        val sessionId = intent?.getStringExtra(EXTRA_SESSION_ID)?.takeIf { it.isNotBlank() } ?: return
        val component = intent.getParcelableExtra<ComponentName>(Intent.EXTRA_CHOSEN_COMPONENT) ?: return
        val packageName = component.packageName
        val label = runCatching {
            val info = context.packageManager.getApplicationInfo(packageName, PackageManager.MATCH_ALL)
            context.packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(packageName)
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
            .putString(KEY_SESSION_ID, sessionId)
            .putString(KEY_TARGET_LABEL, label.take(80))
            .putString(KEY_TARGET_PACKAGE, packageName.take(180))
            .apply()
    }

    companion object {
        const val EXTRA_SESSION_ID = "app.synthos.pocket.extra.SESSION_ID"
        const val PREFERENCES = "synthos-share-target"
        const val KEY_SESSION_ID = "session_id"
        const val KEY_TARGET_LABEL = "target_label"
        const val KEY_TARGET_PACKAGE = "target_package"
    }
}
