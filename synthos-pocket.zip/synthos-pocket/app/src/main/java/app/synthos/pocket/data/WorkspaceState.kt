package app.synthos.pocket.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Small single-source-of-truth state holder. All mutations persist before UI state is committed. */
class WorkspaceState(context: Context) {
    private val store = SecureStore(context.applicationContext)
    var items by mutableStateOf<List<Capture>>(emptyList())
        private set
    var isLoaded by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var operationMessage by mutableStateOf<String?>(null)
        private set
    /** Drop sensitive in-memory records when the UI is locked; encrypted disk data remains intact. */
    fun lock() {
        items = emptyList()
        error = null
        operationMessage = null
        isLoaded = false
    }

    fun load() {
        isLoaded = false
        try {
            items = store.load().sortedByDescending { it.updatedAt }
            error = null
            operationMessage = null
        } catch (_: Exception) {
            error = "SynthOS couldn't open the encrypted workspace. Your saved file has not been overwritten. Retry after unlocking your device, or preserve the app data before reinstalling."
        } finally {
            isLoaded = true
        }
    }

    fun add(content: String, kind: CaptureKind, sourceLabel: String = "Quick capture"): Boolean =
        addCapture(content, kind, sourceLabel) != null

    /** Create a capture and return its persisted record so callers can open/link it immediately. */
    fun addCapture(
        content: String,
        kind: CaptureKind,
        sourceLabel: String = "Quick capture",
        relatedToId: String? = null,
        missionMode: String? = null
    ): Capture? {
        val capture = try {
            CaptureFactory.create(content, kind, sourceLabel).copy(relatedToId = relatedToId, missionMode = missionMode)
        } catch (e: IllegalArgumentException) {
            operationMessage = e.message ?: "Check the captured text and try again."
            return null
        }
        return if (persist(listOf(capture) + items)) capture else null
    }

    fun update(updated: Capture): Boolean {
        if (items.none { it.id == updated.id }) return false
        val safe = updated.copy(
            title = updated.title.trim().take(CaptureFactory.MAX_TITLE_LENGTH),
            content = updated.content.trim().take(CaptureFactory.MAX_CONTENT_LENGTH),
            sourceLabel = updated.sourceLabel.trim().take(120).ifBlank { "Manual edit" },
            updatedAt = System.currentTimeMillis().coerceAtLeast(updated.createdAt)
        )
        if (safe.title.isBlank() || safe.content.isBlank()) {
            operationMessage = "Every saved item needs a title and some content."
            return false
        }
        val saved = persist(items.map { if (it.id == safe.id) safe else it }.sortedByDescending { it.updatedAt })
        return saved
    }

    fun delete(id: String): Boolean {
        if (items.none { it.id == id }) return false
        val next = items.filterNot { it.id == id }.map { item ->
            if (id in item.contextIds) item.copy(contextIds = item.contextIds.filterNot { it == id }) else item
        }.sortedByDescending { it.updatedAt }
        val deleted = persist(next)
        return deleted
    }

    fun importBackup(json: String): Int {
        val imported = CaptureCodec.decode(json)
        val existingIds = items.mapTo(HashSet()) { it.id }
        val additions = imported.filter { it.id !in existingIds }
        if (additions.isEmpty()) return 0
        require(items.size + additions.size <= CaptureCodec.MAX_ITEMS) { "The restored workspace would exceed the ${CaptureCodec.MAX_ITEMS} item limit." }
        if (!persist((items + additions).sortedByDescending { it.updatedAt })) {
            throw IllegalStateException("The restored items could not be saved. Existing data was not intentionally replaced.")
        }
        return additions.size
    }

    private fun persist(next: List<Capture>): Boolean {
        if (!isLoaded) {
            operationMessage = "Unlock the workspace before changing saved data."
            return false
        }
        return try {
            store.save(next)
            items = next
            error = null
            operationMessage = null
            true
        } catch (_: Exception) {
            operationMessage = "The change could not be saved securely. The previous saved workspace remains unchanged. Check device storage and retry."
            false
        }
    }
}
