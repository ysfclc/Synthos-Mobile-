package app.synthos.pocket.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Public, pre-converted LiteRT-LM text models. Downloads go to private app storage. */
data class ModelOption(
    val id: String,
    val name: String,
    val sizeLabel: String,
    val fileName: String,
    val minimumFileBytes: Long,
    val downloadUrl: String,
    val description: String,
    val recommendation: String
)

object ModelCatalog {
    const val CUSTOM_ID = "custom"

    val options = listOf(
        ModelOption(
            id = "qwen3-06b-int4",
            name = "Qwen3 0.6B · Compact",
            sizeLabel = "~329 MB",
            fileName = "Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm",
            minimumFileBytes = 300_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B_dynamic_wi4b32_afp32.litertlm?download=true",
            description = "Smallest download. Best first try on a phone; answers and reasoning are more limited than larger models.",
            recommendation = "BEST FIRST INSTALL"
        ),
        ModelOption(
            id = "qwen3-06b-int8",
            name = "Qwen3 0.6B · Higher precision",
            sizeLabel = "~586 MB",
            fileName = "Qwen3-0.6B.litertlm",
            minimumFileBytes = 550_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm?download=true",
            description = "Same model size with INT8 weights. Uses more storage; quality and speed still depend on the device.",
            recommendation = "BALANCED"
        ),
        ModelOption(
            id = "qwen3-17b-int4",
            name = "Qwen3 1.7B · More capable",
            sizeLabel = "~977 MB",
            fileName = "Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm",
            minimumFileBytes = 900_000_000L,
            downloadUrl = "https://huggingface.co/litert-community/Qwen3-1.7B/resolve/main/Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm?download=true",
            description = "Larger model for more involved tasks. Needs more free storage and memory; low-memory phones may struggle.",
            recommendation = "LARGER MODEL"
        )
    )

    fun fileFor(context: Context, modelId: String): File {
        val directory = File(context.applicationContext.filesDir, "models")
        val option = options.firstOrNull { it.id == modelId }
        val name = when {
            option != null -> option.fileName
            modelId == CUSTOM_ID -> "synthos-local.litertlm"
            else -> "no-active-model.litertlm"
        }
        return File(directory, name)
    }

    fun installedIds(context: Context): Set<String> = options.filter { fileFor(context, it.id).let { file -> file.isFile && file.length() > 10_000_000L } }.mapTo(linkedSetOf()) { it.id }
}

object ModelDownloader {
    /** Download one official .litertlm artifact safely, publishing only after it is complete. */
    suspend fun download(
        context: Context,
        model: ModelOption,
        onProgress: (percent: Int, downloadedBytes: Long, totalBytes: Long) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val directory = File(context.applicationContext.filesDir, "models")
        require(directory.exists() || directory.mkdirs()) { "SynthOS couldn't create private model storage." }
        val destination = ModelCatalog.fileFor(context, model.id)
        val partial = File(directory, model.fileName + ".download")
        val backup = File(directory, model.fileName + ".previous")
        if (!destination.exists() && backup.exists()) {
            require(backup.renameTo(destination)) { "SynthOS couldn't recover the previous model after an interrupted replacement." }
        } else if (destination.exists() && backup.exists()) {
            require(backup.delete()) { "SynthOS couldn't clean up an old replacement file safely." }
        }
        if (partial.exists()) require(partial.delete()) { "SynthOS couldn't clear the incomplete file from an earlier download." }
        val requiredSpace = maxOf(model.minimumFileBytes + 120_000_000L, model.minimumFileBytes * 11L / 10L + 32_000_000L) + (if (destination.isFile) destination.length() else 0L)
        require(directory.usableSpace >= requiredSpace) {
            "Not enough free storage for this model and a safe replacement. Free at least ${requiredSpace / 1_000_000L} MB, then retry."
        }
        var connection: HttpURLConnection? = null
        var completed = false
        var previousMoved = false
        try {
            val activeConnection = (URL(model.downloadUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 45_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "SynthOS-Android/1.3")
                setRequestProperty("Accept-Encoding", "identity")
            }
            connection = activeConnection
            val response = activeConnection.responseCode
            require(activeConnection.url.protocol.equals("https", ignoreCase = true)) { "The model host redirected to a non-secure URL. Nothing was installed." }
            require(response in 200..299) {
                "Model host returned HTTP $response. Check your connection and retry."
            }
            val total = activeConnection.contentLengthLong.coerceAtLeast(-1L)
            activeConnection.inputStream.use { input ->
                FileOutputStream(partial).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    var copied = 0L
                    var lastReport = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        copied += count.toLong()
                        if (copied - lastReport >= 1024 * 1024L || (total > 0 && copied == total)) {
                            lastReport = copied
                            val percent = if (total > 0) ((copied * 100L) / total).toInt().coerceIn(0, 100) else -1
                            onProgress(percent, copied, total)
                        }
                    }
                    output.flush()
                    output.fd.sync()
                    require(copied >= model.minimumFileBytes) {
                        "The model download is incomplete (${copied / 1_000_000L} MB received). Nothing was installed; retry on a stable connection."
                    }
                    require(total <= 0L || copied == total) { "The model download ended early. Retry; the incomplete file was not activated." }
                }
            }
            if (destination.exists()) {
                require(destination.renameTo(backup)) { "The previous model file couldn't be protected while replacing it." }
                previousMoved = true
            }
            if (!partial.renameTo(destination)) {
                if (previousMoved) backup.renameTo(destination)
                previousMoved = false
                error("The completed model couldn't be moved into private storage. The previous model was restored where possible.")
            }
            if (previousMoved) backup.delete()
            previousMoved = false
            completed = true
            onProgress(100, destination.length(), destination.length())
            destination
        } finally {
            connection?.disconnect()
            if (!completed) {
                partial.delete()
                if (previousMoved && backup.exists() && !destination.exists()) backup.renameTo(destination)
            }
        }
    }
}
