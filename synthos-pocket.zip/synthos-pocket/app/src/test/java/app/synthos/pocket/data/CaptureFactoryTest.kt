package app.synthos.pocket.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CaptureFactoryTest {
    @Test
    fun firstNonEmptyLineBecomesTitleAndUrlIsDetected() {
        val capture = CaptureFactory.create("\nResearch this\nhttps://example.com/path", CaptureKind.RESEARCH, "Shared text")
        assertEquals("Research this", capture.title)
        assertEquals("https://example.com/path", capture.sourceUrl)
        assertEquals(CaptureStatus.INBOX, capture.status)
        assertEquals("Shared text", capture.sourceLabel)
    }

    @Test
    fun blankCaptureIsRejected() {
        val result = runCatching { CaptureFactory.create("  \n ", CaptureKind.IDEA) }
        assertTrue(result.isFailure)
    }

    @Test
    fun longContentIsBounded() {
        val capture = CaptureFactory.create("x".repeat(60_000), CaptureKind.REFERENCE)
        assertTrue(capture.content.length <= CaptureFactory.MAX_CONTENT_LENGTH)
        assertNotNull(capture.id)
    }
}
