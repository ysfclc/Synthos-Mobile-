package app.synthos.pocket.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CaptureCodecTest {
    private val sample = Capture(
        id = "capture-1",
        title = "Research local AI",
        content = "Compare local models and keep this URL: https://example.test/docs",
        kind = CaptureKind.RESEARCH,
        status = CaptureStatus.ACTIVE,
        sourceLabel = "Android share",
        sourceUrl = "https://example.test/docs",
        createdAt = 1_700_000_000_000,
        updatedAt = 1_700_000_000_100
    )

    @Test
    fun backupRoundTripPreservesAllFields() {
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(sample)))
        assertEquals(listOf(sample), restored)
    }

    @Test
    fun emptyBackupIsValid() {
        assertEquals(emptyList<Capture>(), CaptureCodec.decode(CaptureCodec.encode(emptyList())))
    }

    @Test
    fun unknownSchemaIsRejected() {
        val backup = CaptureCodec.encode(listOf(sample)).replace("\"schemaVersion\": 1", "\"schemaVersion\": 999")
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode(backup) }
    }

    @Test
    fun duplicateIdsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode(CaptureCodec.encode(listOf(sample, sample))) }
    }

    @Test
    fun invalidJsonIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { CaptureCodec.decode("not json") }
    }
    @Test
    fun backupRoundTripPreservesMissionLinksModeAndContextSelection() {
        val mission = sample.copy(id = "mission-1", missionMode = MissionMode.CONVERGE.name, contextIds = listOf("capture-1"))
        val response = sample.copy(id = "response-1", relatedToId = "mission-1")
        val restored = CaptureCodec.decode(CaptureCodec.encode(listOf(mission, response)))
        assertEquals(listOf(mission, response), restored)
    }

}
