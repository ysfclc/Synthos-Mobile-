package app.synthos.pocket.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalAiPromptComposerTest {
    private fun item(id: String, content: String, source: String = "Quick capture", relatedToId: String? = null) = Capture(
        id = id,
        title = content.take(40),
        content = content,
        kind = CaptureKind.REFERENCE,
        status = CaptureStatus.INBOX,
        sourceLabel = source,
        sourceUrl = null,
        createdAt = when (id) { "user" -> 1_000L; "assistant" -> 2_000L; else -> 3_000L },
        updatedAt = when (id) { "user" -> 1_000L; "assistant" -> 2_000L; else -> 3_000L },
        relatedToId = relatedToId
    )

    @Test
    fun localInstructionIncludesGoalSelectedEvidenceAndReturnedSpecialistWork() {
        val mission = item("mission", "Compare three architectures", "SynthOS mission")
        val selected = item("selected", "Database should be locally encrypted")
        val returned = item("result", "A model recommends SQLite", "Model response", "mission")
        val packet = LocalAiPromptComposer.systemInstruction(mission, listOf(selected), listOf(returned))
        assertTrue(packet.contains("Compare three architectures"))
        assertTrue(packet.contains("Database should be locally encrypted"))
        assertTrue(packet.contains("A model recommends SQLite"))
        assertTrue(packet.contains("not automatically verified facts"))
    }

    @Test
    fun localChatHistoryRestoresOnlyUserAndAssistantTurnsInTimeOrder() {
        val user = item("user", "Compare the proposals", LocalAiPromptComposer.USER_SOURCE)
        val assistant = item("assistant", "Proposal A is better supported", LocalAiPromptComposer.ASSISTANT_SOURCE)
        val unrelated = item("other", "Not part of the private chat")
        val history = LocalAiPromptComposer.history(listOf(assistant, unrelated, user))
        assertEquals(2, history.size)
        assertTrue(history[0].isUser)
        assertFalse(history[1].isUser)
        assertEquals("Proposal A is better supported", history[1].content)
    }
}
