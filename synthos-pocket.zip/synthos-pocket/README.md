# SynthOS 1.2.0 — One mission, one working thread

**Keep the thread of work intact as you move between your context, AI models, apps and the real world.**

SynthOS is a private Android workspace for people who work across AI chats, browser pages, files and notes. A mission is the persistent unit: one goal, a deliberately selected context, local reasoning, specialist handoffs, returned work and the next useful decision.

The product direction is now deliberately **mission-first, not feature-first**. The main workspace has three destinations—Work, Library and Settings. Collaboration is part of the mission itself rather than a separate Council mini-app.

## Shipped in this source snapshot

- **Mission-first workspace:** start and reopen a goal with persistent Collaborate, Compete or Converge strategy.
- **A local conversation inside each mission:** a replaceable on-device inference runtime using Google's LiteRT-LM Android Kotlin API. The app streams responses, restores a bounded conversation history, and supplies the mission goal, only selected context and linked specialist work as the model's instruction context.
- **User-provided model weights:** import a compatible `.litertlm` file through Android's document picker. Model weights are deliberately not bundled in the APK; model size, latency, available RAM and device compatibility differ. Start with a small model listed as supported by the LiteRT-LM project, for example [Qwen3-0.6B in the LiteRT Community](https://huggingface.co/litert-community/Qwen3-0.6B). Select the `.litertlm` file itself, not GGUF, web-only or device-specific NPU variants. GGUF and MediaPipe `.task` files are not interchangeable with `.litertlm`.
- **Specialist handoffs:** create distinct research, architecture and challenge briefs; independent proposals; or proposal / critique / reconciliation briefs. They use Android's Sharesheet, so the user chooses the receiving app and explicitly sends each brief.
- **Return path:** share text or a URL back from a compatible app, review before saving, and link a model response to its mission. Local conversations and returned work are retained in encrypted storage and included in portable backups.
- **Durable context selection:** each mission remembers the exact library records selected for it. Removing a source clears its context links instead of leaving stale references.
- **Library and backups:** search, filter, edit and delete source records; export/import a versioned JSON backup. Exported JSON is plaintext by design and is preceded by a warning.
- **Privacy foundation:** AES-256-GCM encrypted workspace with a non-exportable Android Keystore key and device authentication; no analytics or ads SDK and no `INTERNET` permission.
- **Professional native presentation:** warm paper / evergreen palette, light/dark/system themes, readable type, 48 dp target convention, restrained Compose transitions and honest loading/error states.

## What is real—and what is not yet connected

The local model is real runtime integration, but the user must import compatible weights and actual generation must be validated on a target phone. SynthOS does not bundle a model or silently download one. The first local response can take several seconds while the model initializes; inference speed and memory requirements depend on the model and the device.

External models are **not** automatically called in parallel yet. SynthOS prepares source-aware briefs locally and opens Android's Sharesheet; the user chooses ChatGPT, Claude, Gemini or another app, runs the work there, then shares the result back. The local model can use those returned results when it next answers. API-based concurrent execution, provider-specific browser automation and automated debate rounds are future work—not hidden or simulated integrations.

SynthOS also cannot read private histories from arbitrary apps, control every native app, bypass CAPTCHA, or inspect unrestricted browser tabs. The reliable starting point is Android share-in/share-out plus the visible app workspace. No overlay or broad Accessibility Service is required in this build.

## Core loop

1. **State the goal.** Start a mission that remains in the encrypted workspace.
2. **Choose the working style.** Collaborate splits the work across roles; Compete asks for independent proposals; Converge asks for challenge and reconciliation without manufactured agreement.
3. **Select context.** Choose up to eight saved records. This selection is stored with the mission and is the only library material added to a handoff or local context packet.
4. **Talk to SynthOS locally.** Once a compatible `.litertlm` file is imported, the on-device model can help compare evidence, critique assumptions and plan the next move without sending the conversation to a cloud provider.
5. **Branch out.** Generate a role-specific brief and share it to an AI app. The UI never says that an external provider is running unless the user actually invoked it.
6. **Bring results back.** Share the response to SynthOS, review it and save it linked to the mission.
7. **Continue.** The local assistant sees selected sources and linked returned work; the mission retains the goal, its strategy and context across sessions.

## Architecture choices

- **Native stack:** Kotlin, Jetpack Compose, Material 3 and Android Storage Access Framework. No web shell for the core experience.
- **Local inference:** `com.google.ai.edge.litertlm:litertlm-android:0.18.0`, CPU backend initially, with native generation/lifecycle serialized on a dedicated background dispatcher. The runtime is a replaceable boundary, not the product identity.
- **Storage:** encrypted local records with explicit `relatedToId`, `missionMode` and `contextIds` fields; original captures remain distinct from derived AI responses.
- **Context compilation:** deterministic, bounded composition with source labels, optional URL, selected source excerpts and explicit uncertainty rules. It never grants the model network or other-app access.
- **Motion:** fast, functional transitions that communicate state changes; no decorative “AI is working” simulation.

## Build and release

The source archive is `synthos-pocket.zip` with a top-level `synthos-pocket/` directory. Keep it at the repository root alongside `build-synthos.yml`. The existing GitHub Actions workflow provisions JDK 17, Android SDK Platform 35 and Gradle 8.13, then runs:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug
```

It uploads the APK under the established artifact name **`synthos-pocket-debug-apk`** for 14 days. The build is not reported as passing until that workflow completes successfully. In the current editing runtime, no Android SDK is installed and build downloads are unavailable; the source archive can be verified here, but Android compilation and device inference remain CI/device checks.

## Before relying on this build

- Run the GitHub Actions workflow and inspect the actual build result.
- On the target phone, import a known-compatible small `.litertlm` model and verify the first reply, streaming, second-turn history, switching missions, locking during generation and removing/replacing the model.
- Benchmark memory, startup latency, generation latency, heat and battery. Do not infer acceptable performance from the model file extension alone.
- Run the share-in/share-out loop with at least two AI apps and confirm each response lands in the intended mission.
- Test biometric/Keystore behavior, backup recovery, TalkBack, increased font sizes, low storage and small-screen layout.

See [Product direction](docs/PRODUCT_DIRECTION.md), [Design and motion](docs/DESIGN_MOTION.md) and [QA](docs/QA.md). The source ZIP is not a prebuilt or signed release APK.
