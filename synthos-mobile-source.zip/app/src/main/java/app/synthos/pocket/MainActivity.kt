package app.synthos.pocket

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.synthos.pocket.ui.SynthOsApp
import app.synthos.pocket.ui.SynthOsTheme
import app.synthos.pocket.ui.ThemeMode

class MainActivity : ComponentActivity() {
    private val unlocked = mutableStateOf(false)
    private val authenticationMessage = mutableStateOf<String?>(null)
    private val sharedDraft = mutableStateOf("")
    private var backgroundedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Prevent sensitive workspace snapshots from appearing in screenshots or recents.
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        consumeSharedIntent(intent)
        val preferences = getSharedPreferences("synthos-ui", MODE_PRIVATE)
        val selectedTheme = mutableStateOf(ThemeMode.parse(preferences.getString("theme", "SYSTEM")))
        setContent {
            SynthOsTheme(selectedTheme.value) {
                SynthOsApp(
                    unlocked = unlocked.value,
                    authenticationMessage = authenticationMessage.value,
                    sharedText = sharedDraft.value,
                    themeMode = selectedTheme.value,
                    onUnlock = ::authenticate,
                    onOpenDeviceSecurity = ::openDeviceSecurity,
                    onSharedTextConsumed = { sharedDraft.value = "" },
                    onThemeModeChanged = { mode ->
                        selectedTheme.value = mode
                        preferences.edit().putString("theme", mode.name).apply()
                        applyWindowTheme(mode)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeSharedIntent(intent)
    }

    override fun onStop() {
        if (unlocked.value) backgroundedAt = SystemClock.elapsedRealtime()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (backgroundedAt > 0L && SystemClock.elapsedRealtime() - backgroundedAt >= 60_000L) {
            unlocked.value = false
        }
        backgroundedAt = 0L
        val mode = ThemeMode.parse(getSharedPreferences("synthos-ui", MODE_PRIVATE).getString("theme", "SYSTEM"))
        applyWindowTheme(mode)
    }

    private fun applyWindowTheme(mode: ThemeMode) {
        val systemDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val dark = when (mode) {
            ThemeMode.SYSTEM -> systemDark
            ThemeMode.LIGHT -> false
            ThemeMode.DARK -> true
        }
        val barColor = Color.parseColor(if (dark) "#121914" else "#F6F7F2")
        window.statusBarColor = barColor
        window.navigationBarColor = barColor
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    private fun authenticate() {
        val modernAndroid = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(this)

        // Android 11+ supports the combined authenticator bitmask. On Android 8–10,
        // AndroidX requires setDeviceCredentialAllowed(true) instead; don't reject a
        // valid secure device lock merely because no strong biometric is enrolled.
        if (modernAndroid && manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            authenticationMessage.value = "Set up a strong biometric or secure device lock in Android Settings to unlock SynthOS. Your workspace stays encrypted until authentication is available."
            return
        }

        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock SynthOS")
            .setSubtitle("Authenticate to open your encrypted workspace")
        if (modernAndroid) {
            promptInfoBuilder.setAllowedAuthenticators(authenticators)
        } else {
            promptInfoBuilder.setDeviceCredentialAllowed(true)
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticationMessage.value = null
                    unlocked.value = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticationMessage.value = when (errorCode) {
                        BiometricPrompt.ERROR_USER_CANCELED, BiometricPrompt.ERROR_NEGATIVE_BUTTON -> "Unlock was cancelled. Your workspace remains protected."
                        else -> "Authentication didn't complete. Try again to open your workspace."
                    }
                }
            }
        )
        try {
            prompt.authenticate(promptInfoBuilder.build())
            authenticationMessage.value = null
        } catch (_: Exception) {
            authenticationMessage.value = "Android couldn't start authentication. Configure a screen lock or strong biometric in Android Settings, then try again."
        }
    }

    private fun openDeviceSecurity() {
        try {
            startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
        } catch (_: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {
                authenticationMessage.value = "Open Android Settings and configure a screen lock or strong biometric, then return here."
            }
        }
    }

    private fun consumeSharedIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        if (intent.type != "text/plain" && intent.type != "text/uri-list") return
        val shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (shared.isNotBlank()) sharedDraft.value = shared.take(50_000)
        setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
    }
}
