package app.synthos.pocket.data

import com.google.gson.GsonBuilder
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/** Versioned backup format. Strict validation avoids silently importing malformed data. */
object CaptureCodec {
    const val SCHEMA_VERSION = 1
    const val MAX_BACKUP_BYTES = 10 * 1024 * 1024
    const val MAX_ITEMS = 10_000
    private val gson = GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()

    fun encode(items: List<Capture>): String {
        require(items.size <= MAX_ITEMS) { "This workspace is too large to export." }
        items.forEach { item ->
            require(item.id.isNotBlank() && item.id.length <= 100) { "An item ID is invalid." }
            require(item.title.isNotBlank() && item.title.length <= CaptureFactory.MAX_TITLE_LENGTH) { "An item title is invalid." }
            require(item.content.isNotBlank() && item.content.length <= CaptureFactory.MAX_CONTENT_LENGTH) { "An item's content is invalid." }
            require(item.sourceLabel.length <= 120) { "An item's source label is too long." }
            require(item.sourceUrl == null || (item.sourceUrl.length <= 2048 && (item.sourceUrl.startsWith("https://", true) || item.sourceUrl.startsWith("http://", true)))) {
                "An item's source URL is invalid."
            }
            require(item.createdAt > 0L && item.updatedAt >= item.createdAt) { "An item's timestamps are invalid." }
        }
        // Estimate encoded size before Gson allocates the complete backup; account for JSON escaping.
        val estimatedBytes = items.sumOf { item ->
            estimateJsonStringBytes(item.content) + estimateJsonStringBytes(item.title) +
                estimateJsonStringBytes(item.sourceLabel) + estimateJsonStringBytes(item.sourceUrl.orEmpty()) + 256L
        }
        require(estimatedBytes <= MAX_BACKUP_BYTES.toLong()) { "The backup would exceed the 10 MB limit. Archive or remove older items before exporting." }
        val root = JsonObject().apply {
            addProperty("format", "synthos-backup")
            addProperty("schemaVersion", SCHEMA_VERSION)
            addProperty("exportedAt", System.currentTimeMillis())
            add("items", JsonArray().also { array -> items.forEach { array.add(toJson(it)) } })
        }
        val result = gson.toJson(root)
        require(result.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "The backup exceeds the 10 MB limit." }
        return result
    }

    fun decode(text: String): List<Capture> {
        require(text.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "The backup exceeds the 10 MB limit." }
        val root = try { JsonParser.parseString(text).asJsonObject } catch (_: Exception) {
            throw IllegalArgumentException("This file is not a valid SynthOS backup.")
        }
        require(root.stringOrNull("format") == "synthos-backup") { "This file is not a SynthOS backup." }
        require(root.intOrNull("schemaVersion") == SCHEMA_VERSION) { "This backup version is not supported." }
        val array = root.get("items")
        require(array != null && array.isJsonArray) { "The backup has no item list." }
        require(array.asJsonArray.size() <= MAX_ITEMS) { "The backup contains too many items." }

        val ids = HashSet<String>()
        return array.asJsonArray.map { element ->
            require(element.isJsonObject) { "The backup contains an invalid item." }
            val obj = element.asJsonObject
            val id = obj.stringOrNull("id")?.trim().orEmpty()
            val title = obj.stringOrNull("title")?.trim().orEmpty()
            val content = obj.stringOrNull("content").orEmpty()
            val sourceLabel = obj.stringOrNull("sourceLabel")?.trim().orEmpty()
            val sourceUrl = obj.stringOrNull("sourceUrl")?.trim()?.takeIf { it.isNotEmpty() }
            val kind = CaptureKind.fromStored(obj.stringOrNull("kind").orEmpty())
            val status = CaptureStatus.fromStored(obj.stringOrNull("status").orEmpty())
            val createdAt = obj.longOrNull("createdAt") ?: 0L
            val updatedAt = obj.longOrNull("updatedAt") ?: 0L

            require(id.length in 1..100 && ids.add(id)) { "The backup contains a missing or duplicate item ID." }
            require(title.isNotBlank() && title.length <= CaptureFactory.MAX_TITLE_LENGTH) { "An item title is missing or too long." }
            require(content.isNotBlank() && content.length <= CaptureFactory.MAX_CONTENT_LENGTH) { "An item is empty or exceeds the content limit." }
            require(sourceLabel.length <= 120) { "An item's source label is too long." }
            require(createdAt > 0L && updatedAt >= createdAt) { "An item's timestamps are invalid." }
            require(sourceUrl == null || (sourceUrl.length <= 2048 && (sourceUrl.startsWith("https://", ignoreCase = true) || sourceUrl.startsWith("http://", ignoreCase = true)))) {
                "An item's source URL is invalid."
            }
            Capture(id, title, content, kind, status, sourceLabel.ifBlank { "Imported" }, sourceUrl, createdAt, updatedAt)
        }
    }

    private fun estimateJsonStringBytes(value: String): Long {
        var extra = 0L
        value.forEach { char ->
            extra += when {
                char == '"' || char == '\\' || char == '\n' || char == '\r' || char == '\t' -> 1L
                char.code < 0x20 -> 5L
                else -> 0L
            }
        }
        return value.toByteArray(Charsets.UTF_8).size.toLong() + extra
    }

    private fun toJson(item: Capture) = JsonObject().apply {
        addProperty("id", item.id)
        addProperty("title", item.title)
        addProperty("content", item.content)
        addProperty("kind", item.kind.name)
        addProperty("status", item.status.name)
        addProperty("sourceLabel", item.sourceLabel)
        if (item.sourceUrl == null) add("sourceUrl", com.google.gson.JsonNull.INSTANCE) else addProperty("sourceUrl", item.sourceUrl)
        addProperty("createdAt", item.createdAt)
        addProperty("updatedAt", item.updatedAt)
    }

    private fun JsonObject.stringOrNull(key: String): String? {
        val value = get(key) ?: return null
        if (value.isJsonNull || !value.isJsonPrimitive || !value.asJsonPrimitive.isString) return null
        return value.asString
    }

    private fun JsonObject.intOrNull(key: String): Int? {
        return try {
            val value = get(key) ?: return null
            if (!value.isJsonPrimitive || !value.asJsonPrimitive.isNumber) null else value.asInt
        } catch (_: Exception) { null }
    }

    private fun JsonObject.longOrNull(key: String): Long? {
        return try {
            val value = get(key) ?: return null
            if (!value.isJsonPrimitive || !value.asJsonPrimitive.isNumber) null else value.asLong
        } catch (_: Exception) { null }
    }
}
