# SynthOS Pocket 1.0.0

**Your work, connected.** SynthOS Pocket is a private, offline-first Android workspace for capturing useful material from other apps, preserving context, and preparing structured briefs for the AI tools you already use.

## What works

- **Android Share target:** share text or URLs from an app into SynthOS; review the text before saving it.
- **Quick capture:** save ideas, research, tasks, references and decisions.
- **Local library:** search title/content/source; filter by Inbox, Active, Done and Archived; edit title/content/type/status or delete with confirmation.
- **Council briefs:** select up to eight saved items and compose a source-labelled brief for Synthesize, Research, Challenge or Make a plan. Copy it or send it through Android's Sharesheet to an app you select. SynthOS does not claim to have called those models itself.
- **Private storage:** the workspace is encrypted with AES-256-GCM using a non-exportable Android Keystore key. App access is gated by a strong biometric or secure device credential when supported. The app has no network permission, account, analytics or advertising SDK.
- **Backup/restore:** export a versioned JSON backup through Android's document picker; an explicit warning explains that the exported backup is plaintext. Restore validates the schema and merges only items whose IDs are not already present.
- **System, light and dark themes:** saved locally.

## What this version deliberately does not do

- It does not read private histories inside other AI apps, monitor the screen, scrape notifications, or use an Accessibility Service.
- It does not call AI-provider APIs, require keys, or bundle a large local language model. Model access is through the app the user explicitly chooses to receive a Council brief. Deterministic organization and prompt construction work offline and cost nothing.
- It does not include cloud sync. Move data between devices using an explicitly exported backup; treat that exported file as sensitive.

## Requirements

- Android 8.0 (API 26) or newer; a strong biometric or secure device lock is required to unlock the workspace.
- JDK 17 and Android SDK Platform 35 for building.
- Gradle 8.9. The included `gradlew` script downloads the official Gradle distribution and verifies its published SHA-256 checksum if Gradle 8.9 is not already installed.
- An internet connection is required on the first build to retrieve Gradle and Maven dependencies. The installed app itself has no internet permission and functions offline.

## Build a directly installable APK

From the extracted project directory:

```bash
./gradlew testDebugUnitTest lintDebug assembleDebug
```

On Windows, use `gradlew.bat testDebugUnitTest lintDebug assembleDebug`.

The debug APK is signed by Android's standard debug signing configuration and is suitable for personal sideloading. Output:

`app/build/outputs/apk/debug/app-debug.apk`

Install with Android Debug Bridge:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Or copy the APK to your phone and open it. Android may ask you to permit installation from the file manager you use. Configure a screen lock/strong biometric before first use.

## GitHub Actions

The included `.github/workflows/build-apk.yml` provisions JDK 17, Android SDK and Gradle 8.9; it runs JVM unit tests and Android lint, assembles the debug-signed APK, and uploads it as an artifact. Push to `main`, open a pull request to `main`, or run the workflow manually. A `v*.*.*` tag also creates a GitHub Release with the installable debug APK attached. No repository secrets are required.

## Security notes

- The actual workspace file is stored in app-internal storage as an authenticated AES-GCM ciphertext. Its key is held in Android Keystore and is not written into the project or a normal preferences file.
- `FLAG_SECURE` prevents OS screenshots/screen recording and recent-task snapshots for the app window. This is a privacy aid, not a defense against a compromised/rooted device.
- Backup JSON is intentionally **not encrypted** so a user can move it between applications/devices. Export is gated by a warning; secure the destination yourself.
- Text is handed to other apps only after the user chooses Share/Copy. That action may disclose the selected content to the receiving app.
- Android OS/Keystore behavior and device security remain part of the trust boundary. Keep a current, private backup before changing devices or reinstalling.

## Design system

- **Principles:** clarity over cleverness; one primary action at a time; preserve provenance; local-first privacy; graceful failure over silent data loss.
- **Identity:** SynthOS wordmark plus a geometric `S`; calm editorial interface, warm paper surfaces and evergreen accents.
- **Color tokens:** light primary `#315B45`, accent/tertiary `#984A27`, background `#F6F7F2`, surface `#FFFEFA`, text `#19211B`; dark background `#121914`, surface `#1A231C`, text `#E5EDE6`, primary `#BED8C4`, tertiary `#FFB596`. Semantic success/warning/info tokens and Material error roles are defined centrally in `SynthOsTheme.kt`; XML startup tokens are in `colors.xml`.
- **Typography:** Android system sans; 32/28/24/21 dp-sp display/headline scale; 19/16/14 title scale; 16/14/12 body scale; 14/12/11 labels; explicit line heights in theme.
- **Spacing:** 4 dp base with 8, 12, 16, 18, 20, 24 and 30 dp steps; screen horizontal margin 20 dp; interactive controls generally at least 48 dp.
- **Shapes:** 8, 12, 18, 24 and 30 dp corner scale. Material 3 controls/cards supply consistent interaction states.
- **Icons:** Material Symbols/Compose Outlined family, consistent 20–26 dp and semantic labels.
- **Motion/accessibility:** system-default Material transitions; no required animation; controls use Compose semantics and system-scaled text; color is not the only status indicator; touch targets are sized for mobile.
- **Theme:** System, light and dark. All screen surfaces use the shared Material color, type and shape tokens.
- **Microcopy:** short, direct, specific; destructive operations are confirmed; storage errors never silently reset the workspace.

## Test coverage

JVM tests cover backup round-tripping, malformed/versioned backup rejection, duplicate IDs, content bounds and Council brief construction/truncation limits. Android lint runs as part of CI. Device-only biometric and Keystore behavior should also be exercised on a real supported phone before relying on the app as the sole copy of important data.
